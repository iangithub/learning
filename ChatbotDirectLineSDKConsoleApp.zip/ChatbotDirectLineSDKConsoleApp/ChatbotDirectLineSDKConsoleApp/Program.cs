﻿using Microsoft.Bot.Connector.DirectLine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChatbotDirectLineSDKConsoleApp
{
    class Program
    {
        readonly static string _authkey = "fJuAY51ksh8.PGimGDgzptzXXA4fL3w8nyx2HRIffgBwSTXpWdZysKU";
        readonly static string _botid = "mybot0301";
        readonly static string directlineurl = "https://directline.botframework.com";


        static void Main(string[] args)
        {
            StartBotConversation().Wait();
        }


        private static async Task StartBotConversation()
        {
            DirectLineClient client = new DirectLineClient(_authkey);

            var conversation = await client.Conversations.StartConversationAsync();

            new System.Threading.Thread(async () => await ReadBotMsgAsync(client, conversation.ConversationId)).Start();

            Console.Write("Bot :");

            while (true)
            {
                string input = Console.ReadLine().Trim();

                if (input.Length > 0)
                {
                    Activity usermsg = new Activity
                    {
                        From = new ChannelAccount("Ian"),
                        Text = input,
                        Type = ActivityTypes.Message
                    };

                    await client.Conversations.PostActivityAsync(conversation.ConversationId, usermsg);
                }
            }
        }


        private static async Task ReadBotMsgAsync(DirectLineClient client, string conversationId)
        {
            string watermark = null;

            while (true)
            {
                var replyobj = await client.Conversations.GetActivitiesAsync(conversationId, watermark);
                watermark = replyobj?.Watermark;

                var activities = replyobj.Activities.Where(x => x.From.Id == _botid);
                
                foreach (Activity activity in activities)
                {
                    Console.WriteLine("Text:"+activity.Text + activity.From.Id + activity.From.Name + activity.Type);

                    Console.Write("USER：");
                }
            }
        }
    }
}
