﻿using Microsoft.ML;
using System;
using System.Collections.Generic;

namespace SentimentAnalysisAPP
{
    class Program
    {
        static void Main(string[] args)
        {
            // (1) ===== Create MLContext ==========
            MLContext mlContext = new MLContext();

            // (2) ===== Load trained model ==========
            DataViewSchema modelSchema; //Define DataViewSchema for data preparation pipeline and trained model
            ITransformer trainedModel = mlContext.Model.Load("model.zip", out modelSchema);

            // (3) ===== Single Item ==========
            UseModelWithSingleItem(mlContext, trainedModel);

            // (4) ===== Batch Items ==========
            UseModelWithBatchItems(mlContext, trainedModel);
        }

        private static void UseModelWithSingleItem(MLContext mlContext, ITransformer model)
        {
            // (1) Create Prediction Engine
            PredictionEngine<SentimentData, SentimentPrediction> predictionFunction 
                = mlContext.Model.CreatePredictionEngine<SentimentData, SentimentPrediction>(model);

            // (2) Create Test Sentiment
            SentimentData sampleStatement = new SentimentData
            {
                SentimentText = "This was a very bad steak"
            };

            // (3) Predict
            var resultPrediction = predictionFunction.Predict(sampleStatement);
          
            Console.WriteLine();
            Console.WriteLine("=============== Prediction Test of model  ===============");

            Console.WriteLine();
            Console.WriteLine($"Sentiment: {resultPrediction.SentimentText} " +
                $"| Prediction: {(Convert.ToBoolean(resultPrediction.Prediction) ? "Positive" : "Negative")} " +
                $"| Probability: {resultPrediction.Probability} ");

            Console.WriteLine("=============== End of Predictions ===============");
            Console.WriteLine();
           
        }

        public static void UseModelWithBatchItems(MLContext mlContext, ITransformer model)
        {
            // (1) Create Test Sentiment
            IEnumerable<SentimentData> sentiments = new[]
            {
                new SentimentData{ SentimentText = "This was a horrible meal"},
                new SentimentData{ SentimentText = "I love this spaghetti"}
            };

            // (2) Load batch Test Sentiment

            IDataView batchComments = mlContext.Data.LoadFromEnumerable(sentiments);
            IDataView predictions = model.Transform(batchComments);

            // (3) Use model to predict 
            IEnumerable<SentimentPrediction> predictedResults = mlContext.Data
                .CreateEnumerable<SentimentPrediction>(predictions, reuseRowObject: false);

            // (4)SnippetDisplayResults
            Console.WriteLine();
            Console.WriteLine("=============== Prediction Test of loaded model with multiple samples ===============");
            Console.WriteLine();
           
            foreach (SentimentPrediction prediction in predictedResults)
            {
                Console.WriteLine($"Sentiment: {prediction.SentimentText}" +
                    $" | Prediction: {(Convert.ToBoolean(prediction.Prediction) ? "Positive" : "Negative")} " +
                    $"| Probability: {prediction.Probability} ");
            }
            Console.WriteLine("=============== End of predictions ===============");
        }
    }
}
