﻿using Microsoft.ML;
using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.IO;
using static Microsoft.ML.DataOperationsCatalog;

namespace SentimentAnalysis
{
    class Program
    {
        static readonly string _dataPath = Path.Combine(Environment.CurrentDirectory
            , "Datas", "yelp_labelled.txt");

        static void Main(string[] args)
        {
            Console.WriteLine("=============== Start of process ===============");
            Console.WriteLine();

            // Create ML.NET context/local environment - allows you to add steps in order to keep everything together 
            // as you discover the ML.NET trainers and transforms 
            // (1) ===== <Create MLContext> ==========
            MLContext mlContext = new MLContext();

            // (2) ======= <LoadData> =========
            TrainTestData splitDataView = LoadData(mlContext);

            // (3) ======= <Build And Train Model> ===========
            ITransformer model = BuildAndTrainModel(mlContext, splitDataView.TrainSet);

            // (4) ======== <Evaluate Model> ============
            Evaluate(mlContext, model, splitDataView.TestSet);

            // (5) ======== <Save Model> ============
            mlContext.Model.Save(model, splitDataView.TrainSet.Schema, "model.zip");

            Console.WriteLine();
            Console.WriteLine("=============== End of process ===============");
        }

        public static TrainTestData LoadData(MLContext mlContext)
        {
            //ML.NET also allows you to load data from databases or in-memory collections.
            IDataView dataView = mlContext.Data.LoadFromTextFile<SentimentData>(_dataPath, hasHeader: false);

            /* 
             * You need both a training dataset to train the model and a test dataset to evaluate the model.
             * Split the loaded dataset into train and test datasets
             * Specify test dataset percentage with the `testFraction`parameter
            */
            // <SplitData>
            TrainTestData splitDataView = mlContext.Data.TrainTestSplit(dataView, testFraction: 0.2);

            return splitDataView;
        }

        public static ITransformer BuildAndTrainModel(MLContext mlContext, IDataView splitTrainSet)
        {
            //(1) FeaturizeText and append the machine learning task
            // Create a flexible pipeline (composed by a chain of estimators) for creating/training the model.
            // This is used to format and clean the data.  
            // Convert the text column to numeric vectors (Features column) 
            // Text.FeaturizeText -> FeaturizeText
            // Append BinaryClassification.Trainers -> AddTrainer
            // <SnippetFeaturizeText>
            var estimator = mlContext
                .Transforms.Text.FeaturizeText(outputColumnName: "Features", inputColumnName: nameof(SentimentData.SentimentText))
                .Append(mlContext.BinaryClassification.Trainers.SdcaLogisticRegression(labelColumnName: "Label"
                                                                                        , featureColumnName: "Features"));

            // (2) Create and train the model based on the dataset that has been loaded, transformed.
            //<SnippetTrainModel>
            Console.WriteLine("=============== Create and Train the Model ===============");
            var model = estimator.Fit(splitTrainSet);
            Console.WriteLine("=============== End of training ===============");
            Console.WriteLine();

            // (3) Returns the model we trained to use for evaluation.
            // <SnippetReturnModel>
            return model;
        }

        /// <summary>
        /// Evaluate the model and show accuracy stats
        /// </summary>
        /// <param name="mlContext"></param>
        /// <param name="model"></param>
        /// <param name="splitTestSet"></param>
        public static void Evaluate(MLContext mlContext, ITransformer model, IDataView splitTestSet)
        {
            Console.WriteLine("=============== Evaluating Model accuracy with Test data===============");
            IDataView predictions = model.Transform(splitTestSet);

            // BinaryClassificationContext.Evaluate returns a BinaryClassificationEvaluator.CalibratedResult
            // that contains the computed overall metrics.
            // <SnippetEvaluate>
            CalibratedBinaryClassificationMetrics metrics = mlContext.BinaryClassification.Evaluate(predictions, "Label");

            // The Accuracy metric gets the accuracy of a model, which is the proportion 
            // of correct predictions in the test set.
            // The AreaUnderROCCurve metric is equal to the probability that the algorithm ranks
            // a randomly chosen positive instance higher than a randomly chosen negative one
            // (assuming 'positive' ranks higher than 'negative').
            // The F1Score metric gets the model's F1 score.
            // The F1 score is the harmonic mean of precision and recall:
            //  2 * precision * recall / (precision + recall).
            // <SnippetDisplayMetrics>
            Console.WriteLine();
            Console.WriteLine("Model quality metrics evaluation");
            Console.WriteLine("--------------------------------");
            Console.WriteLine($"Accuracy: {metrics.Accuracy:P2}");
            Console.WriteLine($"Auc: {metrics.AreaUnderRocCurve:P2}");
            Console.WriteLine($"F1Score: {metrics.F1Score:P2}");
            Console.WriteLine("=============== End of model evaluation ===============");
            //</SnippetDisplayMetrics>

        }


    }
}
