﻿======= NuGet ================
Microsoft.ML
Microsoft.ML.ImageAnalytics 
Microsoft.ML.TensorFlow