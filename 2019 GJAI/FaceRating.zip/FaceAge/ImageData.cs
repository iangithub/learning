﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.ML.Data;

namespace FaceAge
{
    public class ImageData
    {
        [LoadColumn(0)]
        public string ImagePath;

        [LoadColumn(1)]
        public float Label;
    }

    public class ImagePrediction : ImageData
    {
        [ColumnName("Score")]
        public float FaceValue;
    }
}
