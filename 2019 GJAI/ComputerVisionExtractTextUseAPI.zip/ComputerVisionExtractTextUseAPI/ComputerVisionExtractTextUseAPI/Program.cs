﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ComputerVisionExtractTextUseAPI
{
    class Program
    {
        private const string subscriptionKey = "e74478caea0b4ebdbb5aea2970f90fbc";
        private const string endpoint = "https://cvdemo1.cognitiveservices.azure.com/vision/v2.1/read/core/asyncBatchAnalyze";
        private const string imgfile = "imgs/3.jpg";

        static void Main(string[] args)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    MakeAnalysisRequest(imgfile);
                    Console.WriteLine("辨識中 ....\n");
                }
                catch (Exception e)
                {
                    Console.WriteLine("\n" + e.Message + "\nPress Enter to exit...\n");
                }
            }
            else
            {
                Console.WriteLine("\n 檔案不存在 \n");
            }
            Console.ReadLine();
        }

        static async void MakeAnalysisRequest(string imgfilepath)
        {
            string operationlocation;
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subscriptionKey);

            // Request body. Posts a locally stored JPEG image.
            byte[] imgdata = GetImageAsByteArray(imgfilepath);

            HttpResponseMessage response;

            using (ByteArrayContent content = new ByteArrayContent(imgdata))
            {
                content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

                // Execute the REST API call.
                response = await client.PostAsync(endpoint, content);
                
            }

            if (response.IsSuccessStatusCode)
                operationlocation = response.Headers.GetValues("Operation-Location").FirstOrDefault();
            else
            {
                string errstring = await response.Content.ReadAsStringAsync();
                Console.WriteLine("Error : " + JToken.Parse(errstring).ToString());
                return;
            }


            string result;
            int i = 0;
            do
            {
                System.Threading.Thread.Sleep(1000);
                response = await client.GetAsync(operationlocation);
                result = await response.Content.ReadAsStringAsync();
                ++i;
            }
            while (i < 30 && result.IndexOf("\"status\":\"Succeeded\"") == -1);

            if (i == 30 && result.IndexOf("\"status\":\"Succeeded\"") == -1)
            {
                Console.WriteLine("\n Services Timeout error.\n");
                return;
            }

            // Display the JSON response.
            Console.WriteLine("======== 辨識結果 ================");
            Console.WriteLine(JToken.Parse(result).ToString());
        }

        static byte[] GetImageAsByteArray(string imagefilepath)
        {
            using (FileStream fileStream =
                new FileStream(imagefilepath, FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }
        }
    }
}
