﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace FaceVerify
{
    class Program
    {
        private const string subscriptionKey = "d5a7995300ed48dda6f7a2ccbc4d6830";
        private const string endpoint = "https://gjfacedemo1.cognitiveservices.azure.com/face/v1.0/detect";
        private const string verifyendpoint = "https://gjfacedemo1.cognitiveservices.azure.com/face/v1.0/verify";
        private const string imgfile1 = "img/s1.jpeg";
        private const string imgfile2 = "img/s2.jpeg";
        private static string faceid1 = string.Empty;
        private static string faceid2 = string.Empty;

        static async Task Main(string[] args)
        {
            Console.WriteLine("臉部辨識中 ....\n");

            if (File.Exists(imgfile1))
            {
                try
                {
                    faceid1 = await MakeAnalysisRequest(imgfile1);
                }
                catch (Exception e)
                {
                    Console.WriteLine("\n" + e.Message + "\nPress Enter to exit...\n");
                }
            }
            else
            {
                Console.WriteLine("\n faceid1 檔案不存在 \n");
            }

            if (File.Exists(imgfile2))
            {
                try
                {
                  faceid2 =  await MakeAnalysisRequest(imgfile2);
                }
                catch (Exception e)
                {
                    Console.WriteLine("\n" + e.Message + "\nPress Enter to exit...\n");
                }
            }
            else
            {
                Console.WriteLine("\n faceid2 檔案不存在 \n");
            }

            if (!string.IsNullOrEmpty(faceid1) && !string.IsNullOrEmpty(faceid2))
            {
                await VerifyFaces(faceid1, faceid2);
            }
            Console.ReadLine();
        }

        static async Task<string> MakeAnalysisRequest(string imageFilePath)
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subscriptionKey);

            // Request parameters.
            string requestParameters = "returnFaceId=true&returnFaceLandmarks=false" +
                "&returnFaceAttributes=age,gender,headPose,smile,facialHair,glasses," +
                "emotion,hair,makeup,occlusion,accessories,blur,exposure,noise";

            // Assemble the URI for the REST API Call.
            string uri = endpoint + "?" + requestParameters;

            HttpResponseMessage response;

            // Request body. Posts a locally stored JPEG image.
            byte[] byteData = GetImageAsByteArray(imageFilePath);

            using (ByteArrayContent content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType =
                    new MediaTypeHeaderValue("application/octet-stream");

                // Execute the REST API call.
                response = await client.PostAsync(uri, content);

                // Get the JSON response.
                string resultstr = await response.Content.ReadAsStringAsync();

                // Display the JSON response.
                Console.WriteLine("======== 辨識結果 ================");
                Console.WriteLine(JToken.Parse(resultstr).ToString());

                return (string)JArray.Parse(resultstr)[0]["faceId"];
            }
        }

        static byte[] GetImageAsByteArray(string imageFilePath)
        {
            using (FileStream fileStream =
                new FileStream(imageFilePath, FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }
        }

        static async Task VerifyFaces(string id1, string id2)
        {
            string result = string.Empty;

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subscriptionKey);
            HttpResponseMessage response;
            string jsonpara = "{\"faceId1\":\"" + faceid1 + "\"," +
                  "\"faceId2\":\"" + faceid2 + "\"}";
            // Request body
            byte[] byteData = Encoding.UTF8.GetBytes(jsonpara);
            using (var content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType =
                   new MediaTypeHeaderValue("application/json");
                response = await client.PostAsync(verifyendpoint, content);
            }

            // Get the JSON response.
            result = await response.Content.ReadAsStringAsync();
            // Display the JSON response.
            Console.WriteLine("======== 辨識結果 ================");
            Console.WriteLine(JToken.Parse(result).ToString());
        }
    }
}
