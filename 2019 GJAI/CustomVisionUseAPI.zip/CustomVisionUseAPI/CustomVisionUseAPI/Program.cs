﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CustomVisionUseAPI
{
    class Program
    {
        private const string subscriptionKey = "d1b16c2db7624e1e9f4039f1a0a65aaf";
        private const string endpoint = "https://japaneast.api.cognitive.microsoft.com/customvision/v3.0/Prediction/5ee99b45-a27d-4b3a-99ab-5e9772445535/classify/iterations/Iteration1/image";
        private const string imgfile = "img/1.jpg";

        static void Main(string[] args)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    MakeAnalysisRequest(imgfile);
                    Console.WriteLine("辨識中 ....\n");
                }
                catch (Exception e)
                {
                    Console.WriteLine("\n" + e.Message + "\nPress Enter to exit...\n");
                }
            }
            else
            {
                Console.WriteLine("\n 檔案不存在 \n");
            }
            Console.ReadLine();
        }

        static async void MakeAnalysisRequest(string imageFilePath)
        {
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Add("Prediction-Key", subscriptionKey);

            // Assemble the URI for the REST API Call.
            string uri = endpoint ;

            HttpResponseMessage response;

            // Request body. Posts a locally stored JPEG image.
            byte[] byteData = GetImageAsByteArray(imageFilePath);

            using (ByteArrayContent content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType =
                    new MediaTypeHeaderValue("application/octet-stream");

                // Execute the REST API call.
                response = await client.PostAsync(uri, content);

                // Get the JSON response.
                string contentString = await response.Content.ReadAsStringAsync();

                // Display the JSON response.
                Console.WriteLine("\n 辨識結果:\n");
                Console.WriteLine(contentString);
            }
        }

        static byte[] GetImageAsByteArray(string imageFilePath)
        {
            using (FileStream fileStream =
                new FileStream(imageFilePath, FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }
        }
    }
}
