﻿========== NuGet =====================
Microsoft.ML
Microsoft.ML.FastTree 

========== Other Step =====================
Copy model.zip to project