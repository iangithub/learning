﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ComputerVisionResizeImg
{
    class Program
    {
        private const string subscriptionKey = "e74478caea0b4ebdbb5aea2970f90fbc";
        private const string endpoint = "https://cvdemo1.cognitiveservices.azure.com/vision/v2.1/generateThumbnail";
        private const string imgfile = "imgs/1.jpg";

        static void Main(string[] args)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    MakeImgProcessRequest(imgfile);
                    Console.WriteLine("處理中 ....\n");
                }
                catch (Exception e)
                {
                    Console.WriteLine("\n" + e.Message + "\nPress Enter to exit...\n");
                }
            }
            else
            {
                Console.WriteLine("\n 檔案不存在 \n");
            }
            Console.ReadLine();
        }

        static async Task MakeImgProcessRequest(string imagefilepath)
        {
            try
            {
                HttpClient client = new HttpClient();

                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subscriptionKey);

                // Request parameters.
                string requestParameters = "width=200&height=150&smartCropping=true";
                string uri = endpoint + "?" + requestParameters;

                HttpResponseMessage response;


                byte[] byteData = GetImageAsByteArray(imagefilepath);

                using (ByteArrayContent content = new ByteArrayContent(byteData))
                {
                    content.Headers.ContentType = new MediaTypeHeaderValue
                        ("application/octet-stream");

                    response = await client.PostAsync(uri, content);
                }


                if (response.IsSuccessStatusCode)
                {
                    // Display the response data.
                    Console.WriteLine("\nResponse:\n{0}", response);

                    byte[] thumbnailImageData = await response.Content.ReadAsByteArrayAsync();

                    string thumbnailFilePath = imagefilepath.Insert(imagefilepath.Length - 4, "_thumb");
                    File.WriteAllBytes(thumbnailFilePath, thumbnailImageData);
                    Console.WriteLine("\nThumbnail written to: {0}", thumbnailFilePath);
                }
                else
                {
                    // Display the JSON error data.
                    string errorString = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Error : {JToken.Parse(errorString).ToString()}");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("\n" + e.Message);
            }
        }

        static byte[] GetImageAsByteArray(string imagefilepath)
        {
            using (FileStream fileStream =
                new FileStream(imagefilepath, FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }
        }
    }
}
