﻿using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComputerVisionExtractTextUseSdk
{
    class Program
    {
        private const string subscriptionKey = "e74478caea0b4ebdbb5aea2970f90fbc";
        private const string endpoint = "https://cvdemo1.cognitiveservices.azure.com/";
        private const string imgfile = "imgs/3.jpg";

        static async Task Main(string[] args)
        {
            ComputerVisionClient computerclient = new ComputerVisionClient(
                new ApiKeyServiceClientCredentials(subscriptionKey),
                new System.Net.Http.DelegatingHandler[] { });
            computerclient.Endpoint = endpoint;

            Console.WriteLine("影像辨識中 ...");

            await ExtractTextLocal(computerclient);

        }

        static async Task ExtractTextLocal(ComputerVisionClient cvclient)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    const int charsinoperationid = 36;
                    using (Stream imgstream = File.OpenRead(imgfile))
                    {
                        BatchReadFileInStreamHeaders textheaders = await cvclient.BatchReadFileInStreamAsync(imgstream);
                        string operationlocation = textheaders.OperationLocation;
                        string operationid = operationlocation.Substring(operationlocation.Length - charsinoperationid);

                        Console.WriteLine(operationlocation);
                        Console.WriteLine(operationid);

                        int i = 0;
                        int maxretries = 30;
                        ReadOperationResult results;
                        Console.WriteLine("==== start ======");
                        do
                        {
                            results = await cvclient.GetReadOperationResultAsync(operationid);
                            Console.WriteLine($"Services status: {results.Status}, waiting {i} seconds...");
                            await Task.Delay(1000);
                            if (maxretries == 29)
                            {
                                Console.WriteLine("Services timed out.");
                            }
                        }
                        while ((results.Status == TextOperationStatusCodes.Running ||
                                results.Status == TextOperationStatusCodes.NotStarted) && i++ < maxretries);


                        var textresults = results.RecognitionResults;

                        foreach (TextRecognitionResult recresult in textresults)
                        {
                            foreach (Line line in recresult.Lines)
                            {
                                Console.WriteLine(line.Text);
                            }
                        }
                        Console.WriteLine("==== end ======");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            else
            {
                Console.WriteLine("No file !!");
            }
        }
    }
}
