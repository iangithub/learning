﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ComputerVisionUseAPI
{
    //Describe Image & Detect Objects
    class Program
    {
        private const string subscriptionKey = "e74478caea0b4ebdbb5aea2970f90fbc";
        private const string endpoint = "https://cvdemo1.cognitiveservices.azure.com/vision/v2.1/analyze";

        private const string imgfile = "img/3.jpg";

        static void Main(string[] args)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    MakeAnalysisRequest(imgfile);
                    Console.WriteLine("辨識中 ....\n");
                }
                catch (Exception e)
                {
                    Console.WriteLine("\n" + e.Message + "\nPress Enter to exit...\n");
                }
            }
            else
            {
                Console.WriteLine("\n 檔案不存在 \n");
            }

            Console.ReadLine();
        }

        static async void MakeAnalysisRequest(string imgfilepath)
        {
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subscriptionKey);

            // Request parameters.
            /* visualFeatures :
             *      Categories , Tags ,Description ,Faces ,ImageType ,Color ,Adult 
             * details : 
             *      Celebrities,Landmarks
             */
            string reqparameter = "visualFeatures=Categories,Tags,Description,Color,Faces,Adult";
            reqparameter += "&details=Celebrities,Landmarks";
            //requestParameters += "&language=zh";


            // Assemble the URI for the REST API Call.
            string uri = endpoint + "?" + reqparameter;

            HttpResponseMessage response;

            // Request body. Posts a locally stored JPEG image.
            byte[] imgdata = GetImageAsByteArray(imgfilepath);

            using (ByteArrayContent content = new ByteArrayContent(imgdata))
            {
                content.Headers.ContentType =
                    new MediaTypeHeaderValue("application/octet-stream");

                // Execute the REST API call.
                response = await client.PostAsync(uri, content);

                // Get the JSON response.
                string result = await response.Content.ReadAsStringAsync();

                // Display the JSON response.
                Console.WriteLine("======== 辨識結果 ================");
                Console.WriteLine(JToken.Parse(result).ToString());
            }
        }

        static byte[] GetImageAsByteArray(string imgfilepath)
        {
            using (FileStream fileStream =
                new FileStream(imgfilepath, FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }
        }
    }
}
