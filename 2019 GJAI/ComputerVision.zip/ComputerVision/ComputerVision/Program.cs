﻿using Microsoft.Azure.CognitiveServices.Vision.ComputerVision;
using Microsoft.Azure.CognitiveServices.Vision.ComputerVision.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ComputerVision
{
    class Program
    {
        private const string subscriptionKey = "e74478caea0b4ebdbb5aea2970f90fbc";
        private const string endpoint = "https://cvdemo1.cognitiveservices.azure.com/";
        private const string imgfile = "imgs/101.jpg";

        private static readonly List<VisualFeatureTypes> features =
            new List<VisualFeatureTypes>()
            {
                VisualFeatureTypes.Categories,
                VisualFeatureTypes.Description,
                VisualFeatureTypes.Faces,
                VisualFeatureTypes.ImageType,
                VisualFeatureTypes.Tags,
                VisualFeatureTypes.Adult,
                VisualFeatureTypes.Objects
            };

        static async Task Main(string[] args)
        {
            ComputerVisionClient cvclient = new ComputerVisionClient(
                new ApiKeyServiceClientCredentials(subscriptionKey),
                new System.Net.Http.DelegatingHandler[] { });

            cvclient.Endpoint = endpoint;

            Console.WriteLine("影像辨識中 ...");

            await AnalyzeAsync2(cvclient);

            Console.ReadLine();
        }

        static async Task AnalyzeAsync2(ComputerVisionClient cvclient)
        {
            if (File.Exists(imgfile))
            {
                using (Stream imgstream = File.OpenRead(imgfile))
                {
                    ImageAnalysis analysis =
                           await cvclient.AnalyzeImageInStreamAsync(imgstream, features);

                    //Description Captions confidence
                    Console.WriteLine("Description Captions:");
                    foreach (var caption in analysis.Description.Captions)
                    {
                        Console.WriteLine($"{caption.Text} with confidence {caption.Confidence}");
                    }
                    Console.WriteLine("=============================================");

                    //Display categories
                    Console.WriteLine("Categories:");
                    foreach (var category in analysis.Categories)
                    {
                        Console.WriteLine($"{category.Name} with confidence {category.Score}");
                    }
                    Console.WriteLine("=============================================");

                    // Display Image tags
                    Console.WriteLine("Tags:");
                    foreach (var tag in analysis.Tags)
                    {
                        Console.WriteLine($"{tag.Name} {tag.Confidence}");
                    }
                    Console.WriteLine("=============================================");

                    //Display Objects
                    Console.WriteLine("Objects:");
                    foreach (var obj in analysis.Objects)
                    {
                        Console.WriteLine($"{obj.ObjectProperty} with confidence {obj.Confidence} at location {obj.Rectangle.X}, " +
                            $"{obj.Rectangle.X + obj.Rectangle.W}, {obj.Rectangle.Y}, {obj.Rectangle.Y + obj.Rectangle.H}");
                    }
                    Console.WriteLine("=============================================");

                    // Faces
                    Console.WriteLine("Faces:");
                    foreach (var face in analysis.Faces)
                    {
                        Console.WriteLine($"A {face.Gender} of age {face.Age} at location {face.FaceRectangle.Left}, " +
                            $"{face.FaceRectangle.Left}, {face.FaceRectangle.Top + face.FaceRectangle.Width}, " +
                            $"{face.FaceRectangle.Top + face.FaceRectangle.Height}");
                    }
                    Console.WriteLine("=============================================");

                    //偵測名人
                    Console.WriteLine("Celebrities:");
                    foreach (var category in analysis.Categories)
                    {
                        if (category.Detail?.Celebrities != null)
                        {
                            foreach (var celeb in category.Detail.Celebrities)
                            {
                                Console.WriteLine($"{celeb.Name} with confidence {celeb.Confidence} at location {celeb.FaceRectangle.Left}, " +
                                    $"{celeb.FaceRectangle.Top}, {celeb.FaceRectangle.Height}, {celeb.FaceRectangle.Width}");
                            }
                        }
                    }
                    Console.WriteLine("=============================================");

                    //偵測地標
                    Console.WriteLine("Landmarks:");
                    foreach (var category in analysis.Categories)
                    {
                        if (category.Detail?.Landmarks != null)
                        {
                            foreach (var landmark in category.Detail.Landmarks)
                            {
                                Console.WriteLine($"{landmark.Name} with confidence {landmark.Confidence}");
                            }
                        }
                    }
                    Console.WriteLine("=============================================");

                    //Display AdultContent
                    Console.WriteLine("AdultContent:");
                    Console.WriteLine($"AdultContent:{analysis.Adult.IsAdultContent}");
                    Console.WriteLine("=============================================");

                    //Detects the image types.
                    Console.WriteLine("Image Type:");
                    Console.WriteLine("Clip Art Type: " + analysis.ImageType.ClipArtType);
                    Console.WriteLine("Line Drawing Type: " + analysis.ImageType.LineDrawingType);
                    Console.WriteLine("=============================================");

                }
            }
            else
            {
                Console.WriteLine("No File");
            }
        }


        /*
         * SDK Desc 
         * ComputerVisionClient 連線物件
         * VisualFeatureTypes 指定完成的不同影像分析類型
         */
        static async Task AnalyzeAsync(ComputerVisionClient cvclient)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    using (Stream imgstream = File.OpenRead(imgfile))
                    {
                        ImageAnalysis analysis =
                            await cvclient.AnalyzeImageInStreamAsync(imgstream, features);

                        //Description Captions confidence
                        Console.WriteLine("Description Captions:");
                        foreach (var caption in analysis.Description.Captions)
                        {
                            Console.WriteLine($"{caption.Text} with confidence {caption.Confidence}");
                        }
                        Console.WriteLine("=============================================");

                        //Display categories
                        Console.WriteLine("Categories:");
                        foreach (var category in analysis.Categories)
                        {
                            Console.WriteLine($"{category.Name} with confidence {category.Score}");
                        }
                        Console.WriteLine("=============================================");

                        // Display Image tags
                        Console.WriteLine("Tags:");
                        foreach (var tag in analysis.Tags)
                        {
                            Console.WriteLine($"{tag.Name} {tag.Confidence}");
                        }
                        Console.WriteLine("=============================================");

                        //Display Objects
                        Console.WriteLine("Objects:");
                        foreach (var obj in analysis.Objects)
                        {
                            Console.WriteLine($"{obj.ObjectProperty} with confidence {obj.Confidence} at location {obj.Rectangle.X}, " +
                                $"{obj.Rectangle.X + obj.Rectangle.W}, {obj.Rectangle.Y}, {obj.Rectangle.Y + obj.Rectangle.H}");
                        }
                        Console.WriteLine("=============================================");

                        // Faces
                        Console.WriteLine("Faces:");
                        foreach (var face in analysis.Faces)
                        {
                            Console.WriteLine($"A {face.Gender} of age {face.Age} at location {face.FaceRectangle.Left}, " +
                                $"{face.FaceRectangle.Left}, {face.FaceRectangle.Top + face.FaceRectangle.Width}, " +
                                $"{face.FaceRectangle.Top + face.FaceRectangle.Height}");
                        }
                        Console.WriteLine("=============================================");

                        //偵測名人
                        Console.WriteLine("Celebrities:");
                        foreach (var category in analysis.Categories)
                        {
                            if (category.Detail?.Celebrities != null)
                            {
                                foreach (var celeb in category.Detail.Celebrities)
                                {
                                    Console.WriteLine($"{celeb.Name} with confidence {celeb.Confidence} at location {celeb.FaceRectangle.Left}, " +
                                        $"{celeb.FaceRectangle.Top}, {celeb.FaceRectangle.Height}, {celeb.FaceRectangle.Width}");
                                }
                            }
                        }
                        Console.WriteLine("=============================================");

                        //偵測地標
                        Console.WriteLine("Landmarks:");
                        foreach (var category in analysis.Categories)
                        {
                            if (category.Detail?.Landmarks != null)
                            {
                                foreach (var landmark in category.Detail.Landmarks)
                                {
                                    Console.WriteLine($"{landmark.Name} with confidence {landmark.Confidence}");
                                }
                            }
                        }
                        Console.WriteLine("=============================================");

                        //Display AdultContent
                        Console.WriteLine("AdultContent:");
                        Console.WriteLine($"AdultContent:{analysis.Adult.IsAdultContent}");
                        Console.WriteLine("=============================================");

                        //Detects the image types.
                        Console.WriteLine("Image Type:");
                        Console.WriteLine("Clip Art Type: " + analysis.ImageType.ClipArtType);
                        Console.WriteLine("Line Drawing Type: " + analysis.ImageType.LineDrawingType);
                        Console.WriteLine("=============================================");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            else
            {
                Console.WriteLine("No file !!");
            }
        }
    }
}
