﻿using Microsoft.ML;
using System;
using System.IO;

namespace MovieRecommendAPP
{
    class Program
    {
        static readonly string _modelZip = Path.Combine(Environment.CurrentDirectory
            , "Datas", "recommendation.zip");

        static void Main(string[] args)
        {
            //(1) Create MLContext
            MLContext mlContext = new MLContext();

            // (2) Load the model
            ITransformer loadedModel = mlContext.Model.Load(_modelZip, out var modelInputSchema);

            // (3) PredictionEngine
            var predictionEngine = mlContext.Model.CreatePredictionEngine
                <MovieRating, MovieRatingPrediction>(loadedModel);

            //(4) Prediction
            var input = new MovieRating { userId = 6, movieId = 8 };
            var movieRatingPrediction = predictionEngine.Predict(input);

            if (Math.Round(movieRatingPrediction.Score, 1) > 3.5)
            {
                Console.WriteLine("Movie " + input.movieId + " is recommended for user " + input.userId + " -- Score" + movieRatingPrediction.Score);
            }
            else
            {
                Console.WriteLine("Movie " + input.movieId + " is not recommended for user " + input.userId + " -- Score" + movieRatingPrediction.Score);
            }
        }
    }
}
