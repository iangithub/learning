﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace CustomVisionUseAPI
{
    class Program
    {
        private const string subscriptionKey = "5fe3a571661845b8983726a743dc1408";
        private const string endpoint = "https://southcentralus.api.cognitive.microsoft.com/customvision/v2.0/Prediction/c101b2c0-3ac3-4385-ad48-4ad35fbecae6/image?iterationId=16ce6811-d495-411e-b5d6-66198d71bf3d";
        private const string imgfile = "img/8.jpg";

        static void Main(string[] args)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    MakeAnalysisRequest(imgfile);
                    Console.WriteLine("辨識中 ....\n");
                }
                catch (Exception e)
                {
                    Console.WriteLine("\n" + e.Message + "\nPress Enter to exit...\n");
                }
            }
            else
            {
                Console.WriteLine("\n 檔案不存在 \n");
            }
            Console.ReadLine();
        }

        static async void MakeAnalysisRequest(string imageFilePath)
        {
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Add("Prediction-Key", subscriptionKey);

            // Assemble the URI for the REST API Call.
            string uri = endpoint ;

            HttpResponseMessage response;

            // Request body. Posts a locally stored JPEG image.
            byte[] byteData = GetImageAsByteArray(imageFilePath);

            using (ByteArrayContent content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType =
                    new MediaTypeHeaderValue("application/octet-stream");

                // Execute the REST API call.
                response = await client.PostAsync(uri, content);

                // Get the JSON response.
                string contentString = await response.Content.ReadAsStringAsync();

                // Display the JSON response.
                Console.WriteLine("\n 辨識結果:\n");
                Console.WriteLine(contentString);
            }
        }

        static byte[] GetImageAsByteArray(string imageFilePath)
        {
            using (FileStream fileStream =
                new FileStream(imageFilePath, FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }
        }
    }
}
