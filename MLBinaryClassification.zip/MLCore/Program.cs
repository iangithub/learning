﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.DataView;
using Microsoft.ML;
using Microsoft.ML.Data;
using Microsoft.ML.Trainers;
using Microsoft.ML.Transforms.Text;

namespace MLCore
{
    class Program
    {
        //def Sample Data path and AI Model path
        static readonly string _dataPath = Path.Combine(Environment.CurrentDirectory, "Data", "yelp_labelled.txt");
        static readonly string _modelPath = Path.Combine(Environment.CurrentDirectory, "Data", "Model.zip");

        static void Main(string[] args)
        {
            // Create ML.NET context
            //MLContext是所有ML.NET操作的起點。提供用於訓練，預測，模型操作
            MLContext mlContext = new MLContext();

            //Load Data (splitDataView.TrainSet & splitDataView.TestSet)
            TrainCatalogBase.TrainTestData splitDataView = LoadData(mlContext);

            //建置和定型模型
            ITransformer model = BuildAndTrainModel(mlContext, splitDataView.TrainSet);

            //使用不同的資料集來評估模型
            Evaluate(mlContext, model, splitDataView.TestSet);

            Console.WriteLine();
            Console.WriteLine("=============== Model finish ===============");
        }

        /// <summary>
        /// 將載入的資料集分割為訓練與測試資料集
        /// </summary>
        /// <param name="mlContext"></param>
        /// <returns></returns>
        public static TrainCatalogBase.TrainTestData LoadData(MLContext mlContext)
        {

            //load training data 
            IDataView dataView = mlContext.Data.LoadFromTextFile<SentimentData>(_dataPath, hasHeader: false);

            //將載入的資料集分割為訓練與測試資料集
            TrainCatalogBase.TrainTestData splitDataView = mlContext.BinaryClassification.TrainTestSplit(dataView, testFraction: 0.2);

            return splitDataView;
        }

        public static ITransformer BuildAndTrainModel(MLContext mlContext, IDataView splitTrainSet)
        {
            //format and clean the data
            //Convert the text column to numeric vectors (Features column特徵欄位)
            /*
             在有效地使用資料集來進行機器學習之前，資料前處理和清除是相當重要的工作。
             原始資料通常雜訊多且不可靠，而可能遺漏值。
             使用資料時，如果未進行這些工作，可能會產生誤導的結果。
             */
            /*
             轉換的主要目的是將資料特徵化，將我們的文字資料轉換成 ML 演算法可辨識的格式—數值向量
             （由數值組成的特徵向量）
             */
            /*
             將文字資料行 (SentimentText) 轉換成名稱為 Features 的數值向量，機器學習演算法會使用此數值向量
             */
            var pipeline = mlContext.Transforms.Text.FeaturizeText
                (outputColumnName: DefaultColumnNames.Features,
                inputColumnName: nameof(SentimentData.SentimentText))

            //加入二元決策樹演算法(附加至pipeline)
            /*
             numLeaves:每個決策樹的最大葉數
             numTrees:決策樹總數
             minDatapointsInLeaves:樣本數據中，樹的葉子允許的最小數據點數
             */
            .Append(mlContext.BinaryClassification.Trainers.FastTree(numLeaves: 50, numTrees: 50, minDatapointsInLeaves: 20));

            // Create and Train the Model
            var model = pipeline.Fit(splitTrainSet);

            // Returns the model we trained to use for evaluation.
            return model;
        }

        /// <summary>
        /// 使用測試資料集評估模型
        /// </summary>
        /// <param name="mlContext"></param>
        /// <param name="model"></param>
        /// <param name="splitTestSet"></param>
        public static void Evaluate(MLContext mlContext, ITransformer model, IDataView splitTestSet)
        {
            /*
                載入測試資料集。
                建立 binaryclassification 評估工具。
                評估模型並建立計量。
                顯示計量。
             */
            //Take the data in, make transformations, output the data. 
            IDataView predictions = model.Transform(splitTestSet);

            //使用指定的資料集來計算 PredictionModel 的品質計量
            CalibratedBinaryClassificationMetrics metrics = mlContext.BinaryClassification.Evaluate(predictions, "Label");

            //顯示模型驗證的計量
            /*
             Accuracy:測試集中正確預測的比例
             Auc:從AUC判斷分類器（預測模型）優劣的標準
                AUC = 1，是完美分類器
                0.5 < AUC < 1，優於隨機猜測。模型妥善設定閾值的話，就能有預測價值。
                AUC = 0.5，模型沒有預測價值
                AUC < 0.5，比隨機猜測還差，預測反指標，但若能維持一定水準，反指標預測也能是一種參考價值
            F1 Score：數值愈高，模型愈穩健
            */
            Console.WriteLine();
            Console.WriteLine("Model quality metrics evaluation");
            Console.WriteLine("--------------------------------");
            Console.WriteLine($"Accuracy: {metrics.Accuracy:P2}");
            Console.WriteLine($"Auc: {metrics.Auc:P2}");
            Console.WriteLine($"F1 Score: {metrics.F1Score:P2}");
            Console.WriteLine("=============== End of model evaluation ===============");

            // Save the new model to .ZIP file
            SaveModelAsFile(mlContext, model);
        }

        /// <summary>
        /// Saves the model we trained to a zip file.
        /// </summary>
        /// <param name="mlContext"></param>
        /// <param name="model"></param>
        private static void SaveModelAsFile(MLContext mlContext, ITransformer model)
        {
            using (var fs = new FileStream(_modelPath, FileMode.Create, FileAccess.Write, FileShare.Write))
                mlContext.Model.Save(model, fs);
        }

    }
}
