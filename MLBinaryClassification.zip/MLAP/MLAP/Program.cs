﻿using Microsoft.Data.DataView;
using Microsoft.ML;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLAP
{
    class Program
    {
        static readonly string _modelPath = Environment.CurrentDirectory + "/Model.zip";

        static void Main(string[] args)
        {
            MLContext mlContext = new MLContext();
            ITransformer model;
            using (var stream = new FileStream(_modelPath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                model = mlContext.Model.Load(stream);
            }
            //UseModelWithSingleItem(mlContext, model);
            UseLoadedModelWithBatchItems(mlContext, model);
        }

        private static void UseModelWithSingleItem(MLContext mlContext, ITransformer model)
        {
            PredictionEngine<SentimentData, SentimentPrediction> predictionFunction = 
                model.CreatePredictionEngine<SentimentData, SentimentPrediction>(mlContext);

            SentimentData testdata = new SentimentData
            {
                SentimentText = "what the funk"
            };

            var resultprediction = predictionFunction.Predict(testdata);
           
            Console.WriteLine();
            Console.WriteLine($"Sentiment: {testdata.SentimentText} | Prediction: {(Convert.ToBoolean(resultprediction.Prediction) ? "Positive" : "Negative")} | Probability: {resultprediction.Probability} ");
        }

        public static void UseLoadedModelWithBatchItems(MLContext mlContext, ITransformer model)
        {
            IEnumerable<SentimentData> sentiments = new[]
            {
                new SentimentData
                {
                    SentimentText = "This was a horrible meal"
                },
                new SentimentData
                {
                    SentimentText = "I love this spaghetti."
                }
            };

            // Load test data  
            IDataView sentimentStreamingDataView = mlContext.Data.LoadFromEnumerable(sentiments);

            IDataView predictions = model.Transform(sentimentStreamingDataView);

            // Use model to predict whether comment data is Positive (1) or Negative (0).
            IEnumerable<SentimentPrediction> predictedResults = mlContext.Data.CreateEnumerable<SentimentPrediction>(predictions, reuseRowObject: false);

            // 合併原始內容及預測結果 (sentiment, prediction)
            IEnumerable<(SentimentData sentiment, SentimentPrediction prediction)> sentimentsAndPredictions = sentiments.Zip(predictedResults, (sentiment, prediction) => (sentiment, prediction));

            foreach ((SentimentData sentiment, SentimentPrediction prediction) item in sentimentsAndPredictions)
            {
                Console.WriteLine($"Sentiment: {item.sentiment.SentimentText} | Prediction: {(Convert.ToBoolean(item.prediction.Prediction) ? "Positive" : "Negative")} | Probability: {item.prediction.Probability} ");
            }
        }
    }
}
