// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.5.0

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;

namespace UIbot.Bots
{
    public class EchoBot : ActivityHandler
    {
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {

            //var reply = MessageFactory.Text("Hi .....");

            //await turnContext.SendActivityAsync(reply, cancellationToken);


            //await turnContext.SendActivityAsync(MessageFactory.Text($"Echo: {turnContext.Activity.Text}"), cancellationToken);


            //receive file
            //var activity = turnContext.Activity;
            //foreach (var item in activity.Attachments)
            //{
            //    //�ɮצ�m
            //    var itemurl = item.ContentUrl;

            //    //do save file to db or any file process
            //    //using (var webClient = new WebClient())
            //    //{
            //    //    webClient.DownloadFile(itemurl, "your local path");
            //    //}

            //    await turnContext.SendActivityAsync(MessageFactory.Text($"Echo: {item.ContentUrl}")
            //        , cancellationToken);
            //}


            ////send img 
            //var reply = MessageFactory.Text("Pizza �f��");
            //reply.Attachments = new List<Attachment>();
            //Attachment att1 = new Attachment();
            //att1.ContentType = "image/png";
            //att1.ContentUrl = "https://www.dominos.com.tw/upload/CKUpload/0073df29-6e72-435f-9d2d-adf2e081035a_320_188.jpg";

            //Attachment att2 = new Attachment();
            //att2.ContentType = "image/png";
            //att2.ContentUrl = "https://www.dominos.com.tw/upload/CKUpload/6589c2ad-66f9-4add-9599-f4e33ea74a62_320_188.jpg";

            //Attachment att3 = new Attachment();
            //att3.ContentType = "image/png";
            //att3.ContentUrl = "https://www.dominos.com.tw/upload/CKUpload/7e3db03a-0f28-46c5-9743-cae36336bf2b_320_188.jpg";

            //reply.Attachments.Add(att1);
            //reply.Attachments.Add(att2);
            //reply.Attachments.Add(att3);
            //await turnContext.SendActivityAsync(reply, cancellationToken);



            ////send file
            //var reply = MessageFactory.Text("ai chatbot doc");
            //reply.Attachments = new List<Attachment>();
            //Attachment att1 = new Attachment();
            //att1.ContentType = "application/pdf";
            //att1.ContentUrl = "https://intelligent-information.blog/wp-content/uploads/2017/09/A-Primer-AI-and-Chatbots-in-Technical-Communication.pdf";
            ////att1.ContentUrl = HttpContext.Current.Server.MapPath("~/files/aichatbot.pdf");
            //att1.Name = "ai chatbot.pdf";
            //reply.Attachments.Add(att1);
            //await turnContext.SendActivityAsync(reply, cancellationToken);



            // Cards are sent as Attachments in the Bot Framework.
            // So we need to create a list of attachments for the reply activity.
            var attachments = new List<Attachment>();

            // Reply to the activity we received with an activity.
            var reply = MessageFactory.Attachment(attachments);

            //HeroCard
            reply.Attachments.Add(GetHeroCard().ToAttachment());
            await turnContext.SendActivityAsync(reply, cancellationToken);

            //HeroCardForMenu
            //reply.Attachments.Add(GetHeroCardForMenu().ToAttachment());
            //await turnContext.SendActivityAsync(reply, cancellationToken);

            //ThumbnailCard
            // reply.Attachments.Add(GetThumbnailCard().ToAttachment());
            //await turnContext.SendActivityAsync(reply, cancellationToken);

            //ReceiptCard
            //reply.Attachments.Add(GetReceiptCard().ToAttachment());
            //await turnContext.SendActivityAsync(reply, cancellationToken);

            //AnimationCard
            //reply.Attachments.Add(GetAnimationCard().ToAttachment());
            //await turnContext.SendActivityAsync(reply, cancellationToken);


            //VideoCard
            //reply.Attachments.Add(GetVideoCard().ToAttachment());
            //await turnContext.SendActivityAsync(reply, cancellationToken);

            // Send the card(s) to the user as an attachment to the activity
            // await turnContext.SendActivityAsync(reply, cancellationToken);


        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text($"Hello and welcome!"), cancellationToken);
                }
            }
        }

        public static HeroCard GetHeroCard()
        {
            var card = new HeroCard
            {
                Title = "Hero Card",
                Subtitle = "�U�P���S���䭷�ͦ�",
                Text = "�x�W�U�a���]28�^��h���촸�A��H���W�Ȱw��_�_��o�����O���ſO���B���X�{�O36�J����",
                Images = new List<CardImage> {
                    new CardImage("https://s.yimg.com/ny/api/res/1.2/qpMJ1gW5agCeKIqsBILa3Q--~A/YXBwaWQ9aGlnaGxhbmRlcjtzbT0xO3c9MTI4MDtoPTk2MA--/https://media-mbst-pub-ue1.s3.amazonaws.com/creatr-uploaded-images/2019-08/5d3f2b10-c923-11e9-bdf6-574a046ace09")
                },
                Buttons = new List<CardAction> {
                    new CardAction(ActionTypes.OpenUrl,
                    "view more",
                    value: "https://tw.news.yahoo.com/%E4%B8%8B%E5%91%A8%E6%81%90%E5%8F%88%E6%9C%89%E9%A2%B1%E9%A2%A8%E7%94%9F%E6%88%90%E7%8E%B2%E7%8E%B2%E5%BD%B1%E9%9F%BF%E5%8F%B0%E7%81%A3%E6%A9%9F%E7%8E%87%E9%AB%98-233749236.html")
                },
            };

            return card;
        }

        private static HeroCard GetHeroCardForMenu()
        {
            var card = new HeroCard
            {
                Text = "���w�A�ڥi�H���z���ѥH�U�A��",
                Buttons = new List<CardAction>
                {
                    new CardAction(ActionTypes.ImBack,"�ڷQ��H�Υd",value: "1"),
                    new CardAction(ActionTypes.ImBack,"�ڷQ�}��",value: "2"),
                    new CardAction(ActionTypes.ImBack,"�d�A�Ⱦ��I",value: "3")
                }
            };
            return card;
        }

        public static ThumbnailCard GetThumbnailCard()
        {
            var card = new ThumbnailCard
            {
                Title = "AI Chatbot �}�o��Խҵ{",
                Subtitle = "AI�����ŧ���i�����A�}�o�z���Ĥ@��AI Chatbot",
                Text = "��Ѿ����H�O���z�LAI�H�u����A�H��r�B�Ϥ����n���P�ϥΪ̡y���ʡz�B�y��ܡz�A���ѦU�ظ�T�P�A�ȡA�ѨM�ϥΪ̪����D�A���y�C��w��10�U�Ӳ�Ѿ����H�Q���D�B�Ω�U��U�~�I",
                Images = new List<CardImage>
                {
                    new CardImage("https://www.pcschool.com.tw/activity/top-2016/GJUN-LOGO.svg")
                },
                Buttons = new List<CardAction>
                {
                    new CardAction(ActionTypes.OpenUrl,
                        "�ԲӸ�T",
                        value: "https://www.pcschool.com.tw/activity/107/1070329_chatbot/index.html?fromto=99003009&gclid=CjwKCAjwo87YBRBgEiwAI1Lkqb86ogSzmdAhagtWHoiz3sIe9eUvaWExx7r_xZKXLYhSjIHfSN_QOxoCp5gQAvD_BwE"
                        )
                }
            };

            return card;
        }

        public static ReceiptCard GetReceiptCard()
        {
            var card = new ReceiptCard
            {
                Title = "�q�椺�e",
                Facts = new List<Fact>
                {
                    new Fact("�q��s��", "Oder12345678"),new Fact("���O���", "2018/5/1"),new Fact("�I�ڸ�T", "VISA 1234-****")
                },
                Items = new List<ReceiptItem>
                {
                    new ReceiptItem("�y�Ϋ��[�o��",
                        price: "$ 200",
                        quantity: "1",
                        image: new CardImage(url: "https://img1.momoshop.com.tw/goodsimg/0004/706/410/4706410_X.jpg")),
                    new ReceiptItem("������y(��)",
                        price: "$ 250",
                        quantity: "1",
                        image: new CardImage(url: "https://img1.momoshop.com.tw/goodsimg/0004/781/728/4781728_X.jpg")),
                },
                Tax = "$ 0",
                Total = "$ 450",
                Buttons = new List<CardAction>
                {
                    new CardAction(
                        ActionTypes.OpenUrl,"�ԲӸ�T",
                        "https://img1.momoshop.com.tw/ecm/img/online/21/411/00/000/bt_1_019_01/bt_1_019_01_e3.jpg",
                        value:"https://www.momoshop.com.tw/category/LgrpCategory.jsp?l_code=2141100000")
                }
            };

            return card;
        }

        public static AnimationCard GetAnimationCard()
        {
            var animationCard = new AnimationCard
            {
                Title = "Microsoft Bot Framework",
                Subtitle = "Animation Card",
                Image = new ThumbnailUrl
                {
                    Url = "https://docs.microsoft.com/en-us/bot-framework/media/how-it-works/architecture-resize.png",
                },
                Media = new List<MediaUrl>
                {
                    new MediaUrl()
                    {
                        Url = "http://i.giphy.com/Ki55RUbOV5njy.gif",
                    },
                },
            };

            return animationCard;
        }

        public static VideoCard GetVideoCard()
        {
            var card = new VideoCard
            {
                Title = "�d�HAI�W��������O�̷|",
                Subtitle = "AI�����ŧ���i�����A�}�o�z���Ĥ@��AI Chatbot",
                Text = "��Ѿ����H�O���z�LAI�H�u����A�H��r�B�Ϥ����n���P�ϥΪ̡y���ʡz�B�y��ܡz�A���ѦU�ظ�T�P�A�ȡA�ѨM�ϥΪ̪����D�A���y�C��w��10�U�Ӳ�Ѿ����H�Q���D�B�Ω�U��U�~�I",
                Image = new ThumbnailUrl
                {
                    Url = "https://www.pcschool.com.tw/activity/107/1070329_chatbot/images/img02.png"
                },
                Media = new List<MediaUrl>
                        {
                            new MediaUrl()
                            {
                                Url = "https://www.youtube.com/watch?v=m6cTCOuLSCc"
                            }
                        },
                Buttons = new List<CardAction>
                        {
                            {
                                new CardAction(ActionTypes.OpenUrl,
                                    "�ԲӸ�T",
                                    value: "https://www.pcschool.com.tw/activity/107/1070329_chatbot/index.html?fromto=99003009&gclid=CjwKCAjwo87YBRBgEiwAI1Lkqb86ogSzmdAhagtWHoiz3sIe9eUvaWExx7r_xZKXLYhSjIHfSN_QOxoCp5gQAvD_BwE")
                            }
                        }
            };
            return card;
        }

    }
}
