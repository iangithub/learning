﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CodeFunLinebot.LineBotService;
using CodeFunLinebot.LineEvent;
using Newtonsoft.Json;
using System.Threading.Tasks;
using CodeFunLinebot.TemplateMessage;
using CodeFunLinebot.TemplateMessage.Action;
using MyLineBotStudy.Models;
using CodeFunLinebot.LineMessage;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime;
using System.Threading;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Newtonsoft.Json.Linq;
using System.Web;
using System.Text;
using System.IO;

namespace MyLineBotStudy.Controllers
{
    public class LinebotController : ApiController
    {
        private readonly string _accesstoken = "your line bot access token";

        //LUIS
        private static CurrencyInfo _currencyInfo = new CurrencyInfo();

        [HttpPost]
        public async Task<IHttpActionResult> Post()
        {
            string postdata = Request.Content.ReadAsStringAsync().Result;
            var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

            try
            {
                if (eventobj.Events[0].Type == "message")
                {
                    CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();
                    var replystr = string.Empty;

                    var luisresult = await GetPrediction(eventobj.Events[0].Message.Text);
                    JObject jobj = JObject.Parse(luisresult.Entities[0].AdditionalProperties["resolution"].ToString());
                    dynamic dynaobj = jobj as dynamic;

                    if (luisresult.TopScoringIntent.Intent == "匯率查詢")
                    {
                        replystr = await FeedbackCurrencyRate((string)dynaobj.values[0]);
                    }
                    else
                    {
                        replystr = "目前無法提供服務";
                    }
                    var replymsg = new CodeFunLinebot.SendReplyMsg.Message[]
                    {
                        new CodeFunLinebot.SendReplyMsg.Message()
                        {
                            Type = "text",
                            Text = replystr
                        }
                    };

                    reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                }

                return Ok();
            }
            catch (Exception ex)
            {
                CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();
                var replymsg = new CodeFunLinebot.SendReplyMsg.Message[]
                    {
                        new CodeFunLinebot.SendReplyMsg.Message()
                        {
                            Type = "text",
                            Text =ex.ToString()
                        }
                    };

                reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                return Ok();
            }
        }

        /// <summary>
        /// Luis 預測語意及萃取幣別
        /// </summary>
        /// <param name="qstr"></param>
        /// <returns></returns>
        static async Task<LuisResult> GetPrediction(string qstr)
        {
            var luiskey = "your luis key";
            var credentials = new ApiKeyServiceClientCredentials(luiskey);
            var luisclient = new LUISRuntimeClient(credentials, new System.Net.Http.DelegatingHandler[] { });
            luisclient.Endpoint = "your luis service url";

            // LUIS APP ID
            var luisappid = "your luis app id";

            // common settings for remaining parameters
            Double? timezoneoffset = null;
            var verbose = true;
            var staging = false;
            var spellCheck = false;
            String bingspellcheckkey = null;
            var log = false;

            // Create prediction client
            var prediction = new Prediction(luisclient);
            return await prediction.ResolveAsync(luisappid, qstr, timezoneoffset, verbose, staging, spellCheck, bingspellcheckkey, log, CancellationToken.None);
        }

        private static async Task<string> FeedbackCurrencyRate(string currency)
        {
            
            string result = @"您詢問的幣別{0}目前匯率
現鈔買入{1}，賣出 {2}
即期買入{3}，賣出{4}
以上匯率來自台銀公告匯率資訊僅供參考，請以實際承作匯率為主。 ";

            //找出幣別匯率
            await FindCurrencyRate();

            if (_currencyInfo != null)
            {
                var item = _currencyInfo.Rates.Find(x => x.CurrencyType == currency);
                if (item != null)
                {
                    result = string.Format(result, currency, item.BuyCash, item.SellCash, item.BuySpot, item.SellSpot);
                }
                else
                {
                    result = "無法提供這個幣別的資訊";
                }
            }

            return result;
        }

        //找出幣別匯率
        private static async Task FindCurrencyRate()
        {
            //記憶體沒有任何匯率資訊
            if (_currencyInfo.Rates == null)
            {
                await DownloadCurrency();
                _currencyInfo.LastTime = DateTime.Now;
            }
            else
            {
                //記憶體暫存的匯率資訊超過1小時，重新更新
                if (_currencyInfo.LastTime.Hour < DateTime.Now.Hour || _currencyInfo.LastTime.Date < DateTime.Now.Date)
                {
                    if (_currencyInfo.Rates != null)
                    {
                        _currencyInfo.Rates.Clear();
                    }
                    await DownloadCurrency();
                    _currencyInfo.LastTime = DateTime.Now;
                }
            }
        }

        //下載匯率資訊
        private static async Task DownloadCurrency()
        {
            var line = string.Empty;
            _currencyInfo.Rates = new System.Collections.Generic.List<CurrencyRate>();

            using (var client = new HttpClient())
            {
                using (var response = await client.GetAsync("https://rate.bot.com.tw/xrt/flcsv/0/day"))
                {
                    using (Stream st = await response.Content.ReadAsStreamAsync())
                    {
                        using (var streader = new StreamReader(st))
                        {
                            var i = 0;
                            while ((line = streader.ReadLine()) != null)
                            {
                                string[] split = line.Split(',');
                                if (i > 0)
                                {
                                    var item = new CurrencyRate();
                                    item.CurrencyType = split[0];
                                    item.BuyCash = decimal.Parse(split[2]);
                                    item.BuySpot = decimal.Parse(split[3]);
                                    item.SellCash = decimal.Parse(split[12]);
                                    item.SellSpot = decimal.Parse(split[13]);
                                    _currencyInfo.Rates.Add(item);
                                }
                                i++;
                            }
                        }
                    }
                }
            }
        }

    }
}
