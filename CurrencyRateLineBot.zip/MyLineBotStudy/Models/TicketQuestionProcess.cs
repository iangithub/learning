﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;

namespace MyLineBotStudy.Models
{
    public class Ticket
    {
        public Ticket()
        {
            this.Status = 0;
        }

        /// <summary>
        /// 車票日期
        /// </summary>
        public DateTime? Day { get; set; }

        /// <summary>
        /// 車票張數
        /// </summary>
        public int? Cnt { get; set; }

        /// <summary>
        /// 出發地

        /// </summary>
        public string From { get; set; }

        /// <summary>
        /// 目的地
        /// </summary>
        public string To { get; set; }

        /// <summary>
        /// 對話物件狀態
        /// </summary>
        public int Status { get; internal set; }
    }

    public static class TickerConversation
    {
        public static List<string> Process(ref Ticket ticketobj, string val)
        {
            var result = new List<string>();

            if (ticketobj == null)
            {
                throw new Exception("Ticket can't be null");
            }

            switch (ticketobj.Status)
            {
                case 1:
                    ticketobj.Day = DateTime.Parse(val);
                    break;
                case 2:
                    ticketobj.Cnt = int.Parse(val);
                    break;
                case 3:
                    ticketobj.From = val;
                    break;
                case 4:
                    ticketobj.To = val;
                    break;
            }

            if (!ticketobj.Day.HasValue)
            {
                result.Add("請問你要訂哪一天的車票");
                ticketobj.Status = 1;
            }
            else if (!ticketobj.Cnt.HasValue)
            {
                result.Add("請問需要幾張");
                ticketobj.Status = 2;
            }
            else if (string.IsNullOrEmpty(ticketobj.From))
            {
                result.Add("從哪個車站出發的呢");
                ticketobj.Status = 3;
            }
            else if (string.IsNullOrEmpty(ticketobj.To))
            {
                result.Add("要到哪個車站呢");
                ticketobj.Status = 4;
            }

            return result;
        }
    }
}