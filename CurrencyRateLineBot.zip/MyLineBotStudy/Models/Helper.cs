﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace MyLineBotStudy.Models
{
    public static class Helper
    {
        public static void WriteEventLog(string str)
        {
            using (EventLog eventLog = new EventLog("Application"))
            {
                eventLog.Source = "Application";
                eventLog.WriteEntry(str);
            }
        }
    }
}