﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLineBotStudy.Models
{
    public class Question
    {
        [JsonProperty("question")]
        public string QuestionStr { get; set; } //要詢問的問題
        [JsonProperty("top")]
        public int Top { get; set; } //取回分數最高的答案筆數
    }

    public class AnswerResult
    {
        [JsonProperty("answers")]
        public List<Answer> Answers { get; set; }
    }
    public class Answer
    {
        [JsonProperty("answer")]
        public string AnswerStr { get; set; }
        [JsonProperty("questions")]
        public List<string> Questions { get; set; }
        [JsonProperty("score")]
        public float Score { get; set; }
    }
}
