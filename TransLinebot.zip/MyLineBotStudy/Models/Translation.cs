﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyLineBotStudy.Models
{
    public class Translation
    {
        [JsonProperty("detectedLanguage")]
        public Detectedlanguage DetectedLanguage { get; set; }
        [JsonProperty("translations")]
        public TranslationResult[] Translations { get; set; }
    }

    public class Detectedlanguage
    {
        [JsonProperty("language")]
        public string Language { get; set; }
        [JsonProperty("score")]
        public float Score { get; set; }
    }

    public class TranslationResult
    {
        [JsonProperty("text")]
        public string Text { get; set; }
        [JsonProperty("to")]
        public string To { get; set; }
    }
}