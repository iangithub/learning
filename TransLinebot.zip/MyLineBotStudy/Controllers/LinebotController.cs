﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CodeFunLinebot.LineBotService;
using CodeFunLinebot.LineEvent;
using Newtonsoft.Json;
using System.Threading.Tasks;
using CodeFunLinebot.TemplateMessage;
using CodeFunLinebot.TemplateMessage.Action;
using MyLineBotStudy.Models;
using CodeFunLinebot.LineMessage;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime;
using System.Threading;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Newtonsoft.Json.Linq;
using System.Web;
using System.Text;
using System.IO;

namespace MyLineBotStudy.Controllers
{
    public class LinebotController : ApiController
    {
        private readonly string _accesstoken = "50wDwbPSG1TiVHBxJbkNR74hpDxe0pcv1eIxcgoCtBjlzOziYGFf444W4Udmv9h0Nc2DKi+DefGypdzxWub1q0RNX29BmpGvdZfU+d6t7rS8JPQMu5ncjrqDOe/wMBc5BRrpcdSn8GSlU1AYP5gsHAdB04t89/1O/w1cDnyilFU=";


        [HttpPost]
        public async Task<IHttpActionResult> Post()
        {
            if (HttpContext.Current.Application["lang"] == null)
            {
                HttpContext.Current.Application["lang"] = "en";
            }

            string postdata = Request.Content.ReadAsStringAsync().Result;
            var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

            try
            {
                if (eventobj.Events[0].Type == "message")
                {

                    var cmdmsg = string.Empty;
                    var usermsg = eventobj.Events[0].Message.Text;

                    switch (usermsg.Replace("?", "").Replace("？", ""))
                    {
                        case "日文":
                            HttpContext.Current.Application["lang"] = "ja";
                            cmdmsg = "好的，接下來會翻譯成日文囉";
                            break;
                        case "英文":
                            HttpContext.Current.Application["lang"] = "en";
                            cmdmsg = "好的，接下來會翻譯成英文囉";
                            break;
                        case "韓文":
                            HttpContext.Current.Application["lang"] = "ko";
                            cmdmsg = "好的，接下來會翻譯成韓文囉";
                            break;
                    }

                    if (!string.IsNullOrEmpty(cmdmsg))
                    {
                        var replymsg = new CodeFunLinebot.SendReplyMsg.Message[]
                        {
                            new CodeFunLinebot.SendReplyMsg.Message()
                            {
                                Type = "text",
                                Text = cmdmsg
                            }
                        };
                        cmdmsg = string.Empty;
                        CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();
                        reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                    }
                    else
                    {
                        var transresult = await GoTranslate(usermsg, HttpContext.Current.Application["lang"].ToString());
                        var replymsg = new CodeFunLinebot.SendReplyMsg.Message[]
                        {
                            new CodeFunLinebot.SendReplyMsg.Message()
                            {
                                Type = "text",
                                Text = transresult
                            }
                        };
                        CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();
                        reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                    }
                }

                return Ok();
            }
            catch (Exception ex)
            {
                var replymsg = new CodeFunLinebot.SendReplyMsg.Message[]
                        {
                            new CodeFunLinebot.SendReplyMsg.Message()
                            {
                                Type = "text",
                                Text = ex.ToString()
                            }
                        };
                CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();
                reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                return Ok();
            }
        }

        static async Task<string> GoTranslate(string talkword, string lang)
        {
            string result = string.Empty;
            string host = "https://api.cognitive.microsofttranslator.com";
            string path = "/translate?api-version=3.0";
            // Translate to English
            string paras = "&to=" + lang;
            //string paras = "&to=en";

            //Get from Azure
            string key = "e98090e611a44f0fb82c221b8ddec72e";
            string uri = host + path + paras;

            System.Object[] body = new System.Object[] { new { Text = talkword } };
            var requestBody = JsonConvert.SerializeObject(body);

            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri(uri);
                request.Content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                request.Headers.Add("Ocp-Apim-Subscription-Key", key);

                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();
                List<Translation> tranresult = JsonConvert.DeserializeObject<List<Translation>>(responseBody);
                result = tranresult[0].Translations[0].Text;
            }
            return result;
        }

        //Currency Rate Line bot with LUIS
        /*

        //LUIS
        private static CurrencyInfo _currencyInfo = new CurrencyInfo();

        [HttpPost]
        public async Task<IHttpActionResult> Post()
        {
            string postdata = Request.Content.ReadAsStringAsync().Result;
            var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

            try
            {
                if (eventobj.Events[0].Type == "message")
                {
                    CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();
                    var replystr = string.Empty;

                    var luisresult = await GetPrediction(eventobj.Events[0].Message.Text);
                    JObject jobj = JObject.Parse(luisresult.Entities[0].AdditionalProperties["resolution"].ToString());
                    dynamic dynaobj = jobj as dynamic;

                    if (luisresult.TopScoringIntent.Intent == "匯率查詢")
                    {
                        replystr = await FeedbackCurrencyRate((string)dynaobj.values[0]);
                    }
                    else
                    {
                        replystr = "目前無法提供服務";
                    }
                    var replymsg = new CodeFunLinebot.SendReplyMsg.Message[]
                    {
                        new CodeFunLinebot.SendReplyMsg.Message()
                        {
                            Type = "text",
                            Text = replystr
                        }
                    };

                    reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                }

                return Ok();
            }
            catch (Exception ex)
            {
                CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();
                var replymsg = new CodeFunLinebot.SendReplyMsg.Message[]
                    {
                        new CodeFunLinebot.SendReplyMsg.Message()
                        {
                            Type = "text",
                            Text =ex.ToString()
                        }
                    };

                reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                return Ok();
            }
        }

        /// <summary>
        /// Luis 預測語意及萃取幣別
        /// </summary>
        /// <param name="qstr"></param>
        /// <returns></returns>
        static async Task<LuisResult> GetPrediction(string qstr)
        {
            var luiskey = "7b25c16fde734fcfb6b9650cd4a5b01b";
            var credentials = new ApiKeyServiceClientCredentials(luiskey);
            var luisclient = new LUISRuntimeClient(credentials, new System.Net.Http.DelegatingHandler[] { });
            luisclient.Endpoint = "https://westus.api.cognitive.microsoft.com";

            // LUIS APP ID
            var luisappid = "fea8561f-9266-4a48-97a5-6c5274618363";

            // common settings for remaining parameters
            Double? timezoneoffset = null;
            var verbose = true;
            var staging = false;
            var spellCheck = false;
            String bingspellcheckkey = null;
            var log = false;

            // Create prediction client
            var prediction = new Prediction(luisclient);
            return await prediction.ResolveAsync(luisappid, qstr, timezoneoffset, verbose, staging, spellCheck, bingspellcheckkey, log, CancellationToken.None);
        }

        private static async Task<string> FeedbackCurrencyRate(string currency)
        {

            string result = @"您詢問的幣別{0}目前匯率
現鈔買入{1}，賣出 {2}
即期買入{3}，賣出{4}
以上匯率來自台銀公告匯率資訊僅供參考，請以實際承作匯率為主。 ";

            //找出幣別匯率
            await FindCurrencyRate();

            if (_currencyInfo != null)
            {
                var item = _currencyInfo.Rates.Find(x => x.CurrencyType == currency);
                if (item != null)
                {
                    result = string.Format(result, currency, item.BuyCash, item.SellCash, item.BuySpot, item.SellSpot);
                }
                else
                {
                    result = "無法提供這個幣別的資訊";
                }
            }

            return result;
        }

        //找出幣別匯率
        private static async Task FindCurrencyRate()
        {
            //記憶體沒有任何匯率資訊
            if (_currencyInfo.Rates == null)
            {
                await DownloadCurrency();
                _currencyInfo.LastTime = DateTime.Now;
            }
            else
            {
                //記憶體暫存的匯率資訊超過1小時，重新更新
                if (_currencyInfo.LastTime.Hour < DateTime.Now.Hour || _currencyInfo.LastTime.Date < DateTime.Now.Date)
                {
                    if (_currencyInfo.Rates != null)
                    {
                        _currencyInfo.Rates.Clear();
                    }
                    await DownloadCurrency();
                    _currencyInfo.LastTime = DateTime.Now;
                }
            }
        }

        //下載匯率資訊
        private static async Task DownloadCurrency()
        {
            var line = string.Empty;
            _currencyInfo.Rates = new System.Collections.Generic.List<CurrencyRate>();

            using (var client = new HttpClient())
            {
                using (var response = await client.GetAsync("https://rate.bot.com.tw/xrt/flcsv/0/day"))
                {
                    using (Stream st = await response.Content.ReadAsStreamAsync())
                    {
                        using (var streader = new StreamReader(st))
                        {
                            var i = 0;
                            while ((line = streader.ReadLine()) != null)
                            {
                                string[] split = line.Split(',');
                                if (i > 0)
                                {
                                    var item = new CurrencyRate();
                                    item.CurrencyType = split[0];
                                    item.BuyCash = decimal.Parse(split[2]);
                                    item.BuySpot = decimal.Parse(split[3]);
                                    item.SellCash = decimal.Parse(split[12]);
                                    item.SellSpot = decimal.Parse(split[13]);
                                    _currencyInfo.Rates.Add(item);
                                }
                                i++;
                            }
                        }
                    }
                }
            }
        }
        */

        /*
        [HttpPost]
        public IHttpActionResult Post()
        {
            try
            {
                string postdata = Request.Content.ReadAsStringAsync().Result;
                var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

                if (eventobj.Events[0].Type == "message")
                {

                    #region Sticker

                    //var userid = eventobj.Events[0].Source.UserId;
                    //PushMsg botpush = new PushMsg(_accesstoken);
                    //var sticker = new StickerMessageObj()
                    //{
                    //    PackageId = "11537",
                    //    StickerId = "52002734"
                    //};

                    //botpush.Send(userid, sticker);

                    #endregion

                    #region Img

                    var userid = eventobj.Events[0].Source.UserId;
                    PushMsg botpush = new PushMsg(_accesstoken);
                    var img = new ImageMessageObj()
                    {
                        PreviewImageUrl = "https://imgdatas.blob.core.windows.net/beauty/linebot2.jpg",
                        OriginalContentUrl = "https://imgdatas.blob.core.windows.net/beauty/linebot1.jpg"
                    };

                    botpush.Send(userid, img);

                    #endregion

                    #region Video

                    //var userid = eventobj.Events[0].Source.UserId;
                    //PushMsg botpush = new PushMsg(_accesstoken);
                    //var video = new VideoMessageObj()
                    //{
                    //    PreviewImageUrl = "https://imgdatas.blob.core.windows.net/beauty/linebot2.jpg",
                    //    OriginalContentUrl = "https://imgdatas.blob.core.windows.net/beauty/1.mp4"
                    //};

                    //botpush.Send(userid, video);

                    #endregion

                    #region Location

                    //var userid = eventobj.Events[0].Source.UserId;
                    //PushMsg botpush = new PushMsg(_accesstoken);
                    //var location = new LocationMessageObj()
                    //{
                    //    Title = "營業門市",
                    //    Address = "高雄市中正區888號",
                    //    Latitude = "25.052636",
                    //    Longitude = "121.5184701"
                    //};

                    //botpush.Send(userid, location);

                    #endregion

                    #region Button Template

                    //var userid = eventobj.Events[0].Source.UserId;
                    //PushMsg botpush = new PushMsg(_accesstoken);

                    //var template = new ButtonTemplateObject()
                    //{
                    //    Text = "旅行目的地",
                    //    Title = "請問你想去哪裡玩呢?",
                    //    Actions = new List<TemplateMessageActionBase>() {
                    //                            new PostbackAction(){Text="日本",Label="日本",Data="Japan"},
                    //                            new PostbackAction(){Text="韓國",Label="韓國",Data="Korea"}
                    //                        }
                    //};

                    //botpush.Send(userid, template, "旅行目的地-想去哪裡玩");

                    #endregion

                    #region Confirm Template

                    //var userid = eventobj.Events[0].Source.UserId;
                    //PushMsg botpush = new PushMsg(_accesstoken);
                    //var template = new ConfirmTemplateObject()
                    //{
                    //    Text = "確定取消訂單",
                    //    Actions = new List<TemplateMessageActionBase>() {
                    //        new MessageAction(){Text="確定",Label="Yes"},
                    //        new MessageAction(){Text="取消",Label="No"}
                    //    }
                    //};
                    //botpush.Send(userid, template, "確定取消訂單");

                    #endregion

                    #region Carousel Template

                    //var userid = eventobj.Events[0].Source.UserId;
                    //PushMsg botpush = new PushMsg(_accesstoken);

                    //var columns = new List<CarouselColumnObject>();
                    //var column1 = new CarouselColumnObject();
                    //column1.Text = "東京酷航自由行 5 天";
                    //column1.ThumbnailImageUrl = "https://image.cdn-eztravel.com.tw/iNR9UgZw_GHmvvxIRK-LCb5BGC2NShDMFCNRAnKGBwA/rs:fill:385:370:1/g:ce/aHR0cHM6Ly93d3cuZXp0cmF2ZWwuY29tLnR3L2ltZy9GUlQvRlJUMDAwMDAxNTE5OC5naWY.png";
                    //column1.Actions = new List<TemplateMessageActionBase>() {
                    //    new UriAction(){Uri="https://vacation.eztravel.com.tw/fit/introduction/FRT0000015198?quintstars=05&_ga=2.30507705.786028089.1561948836-1896116766.1561948836&_gac=1.120387322.1561948836.Cj0KCQjwu-HoBRD5ARIsAPIPenfJ7EQOteyge58AE_SGTPR6JhO5_RxgyPXG8PiSt6YNhHKf0n5yl38aAluUEALw_wcB"
                    //    ,Label="詳情"}
                    //};
                    //columns.Add(column1);

                    //var column2 = new CarouselColumnObject();
                    //column2.Text = "灌籃高手電車站．箱根遊船 5 天";
                    //column2.ThumbnailImageUrl = "https://image.cdn-eztravel.com.tw/35suFv4et5L2f3CXdkpK0HMqIarAhlh3950IS_HXTSs/rs:fill:385:370:1/g:ce/aHR0cHM6Ly93d3cuZXp0cmF2ZWwuY29tLnR3L2ltZy9GUk4vRlJOMDAwMDAxNjg5MS5naWY.png";
                    //column2.Actions = new List<TemplateMessageActionBase>() {
                    //    new UriAction(){Uri="https://vacation.eztravel.com.tw/pkgfrn/introduction/FRN0000016891?_ga=2.29977273.786028089.1561948836-1896116766.1561948836&_gac=1.190173401.1561949444.Cj0KCQjwu-HoBRD5ARIsAPIPenfJ7EQOteyge58AE_SGTPR6JhO5_RxgyPXG8PiSt6YNhHKf0n5yl38aAluUEALw_wcB"
                    //    ,Label="詳情"}
                    //};
                    //columns.Add(column2);

                    //var template = new CarouselTemplateObject()
                    //{
                    //    Columns = columns,
                    //};


                    //botpush.Send(userid, template, "東京行程推薦");

                    #endregion
                }

                return Ok();
            }
            catch (Exception)
            {
                return Ok();
            }
        }

        */

        /*
                [HttpPost]
                public IHttpActionResult Post()
                {

                    try
                    {
                        string postdata = Request.Content.ReadAsStringAsync().Result;
                        var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

                        if (eventobj.Events[0].Type == "message")
                        {
                            CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();

                            var replymsg = new CodeFunLinebot.SendReplyMsg.Message[]
                            {
                                new CodeFunLinebot.SendReplyMsg.Message()
                                {
                                    Type = "text",
                                    Text ="Data:"+eventobj.Events[0].Message.Latitude+"/"+eventobj.Events[0].Message.Longitude
                                }
                            };

                            reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                        }

                        return Ok();
                    }
                    catch (Exception)
                    {
                        return Ok();
                    }
                }
        */

        /*
                [HttpPost]
                public async Task<IHttpActionResult> PostAsync()
                {

                    try
                    {
                        string postdata = Request.Content.ReadAsStringAsync().Result;
                        var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

                        if (eventobj.Events[0].Source.Type == "message")
                        {
                            var userid = eventobj.Events[0].Source.UserId;


                            CodeFunLinebot.User.UserInfoObj userobj = await CodeFunLinebot.LineBotService.User.GetInfoAsync(_accesstoken, userid);


                            CodeFunLinebot.LineBotService.ReplyMsg reply = new ReplyMsg();

                            CodeFunLinebot.SendReplyMsg.Message[] replymsg = new CodeFunLinebot.SendReplyMsg.Message[] {
                                new CodeFunLinebot.SendReplyMsg.Message()
                                {
                                    Type = "text",
                                    Text = userobj.DisplayName+"/"+userobj.StatusMessage
                                }
                            };

                            reply.Send(_accesstoken, eventobj.Events[0].ReplyToken, replymsg);
                        }

                        return Ok();
                    }
                    catch (Exception)
                    {
                        return Ok();
                    }
                }
                */

        /*
                [HttpPost]
                public IHttpActionResult Post()
                {
                    try
                    {
                        string postdata = Request.Content.ReadAsStringAsync().Result;
                        var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

                        if (eventobj.Events[0].Type == "message")
                        {
                            var userid = eventobj.Events[0].Source.UserId;
                            PushMsg botpush = new PushMsg(_accesstoken);
                            var template = new ConfirmTemplateObject()
                            {
                                Text = "確定取消訂單",
                                Actions = new List<TemplateMessageActionBase>() {
                                    new MessageAction(){Text="確定",Label="Yes"},
                                    new MessageAction(){Text="取消",Label="No"}
                                }
                            };
                            botpush.Send(userid, template, "確定取消訂單");
                        }
                        return Ok();
                    }
                    catch (Exception)
                    {
                        return Ok();
                    }
                }
                */

        //QnA Maker
        /*
        [HttpPost]
        public async Task<IHttpActionResult> Post()
        {
            string postdata = Request.Content.ReadAsStringAsync().Result;
            var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

            string url = "https://techdemo.azurewebsites.net/qnamaker/knowledgebases/a7af167f-158c-4f29-8702-8eba496c5447/generateAnswer";
            string endpoint_key = "e2c94fd5-7d18-4c34-81af-57be791919e1";

            try
            {
                if (eventobj.Events[0].Type == "message")
                {
                    AnswerResult qnaresult = new AnswerResult();
                    var question = new Question()
                    {
                        QuestionStr = eventobj.Events[0].Message.Text,
                        Top = 1
                    };

                    using (var client = new HttpClient())
                    {
                        using (var request = new HttpRequestMessage())
                        {
                            request.Method = HttpMethod.Post;
                            request.RequestUri = new Uri(url);
                            request.Headers.Add("Authorization", "EndpointKey "
                                + endpoint_key);

                            request.Content = new StringContent(
                                JsonConvert.SerializeObject(question)
                                , Encoding.UTF8, "application/json");

                            var response = await client.SendAsync(request);

                            var val = await response.Content.ReadAsStringAsync();
                            qnaresult = JsonConvert.DeserializeObject<AnswerResult>(val);

                            ReplyMsg botreply = new ReplyMsg(_accesstoken);
                            var replymsg = new TextMessageObj();
                            replymsg.Text = qnaresult.Answers[0].AnswerStr;
                            botreply.Send(eventobj.Events[0].ReplyToken, replymsg);
                        }
                    }
                }

                return Ok();
            }
            catch (Exception)
            {
                return Ok();
            }
        }
        */

        //連續對話
        /*
        [HttpPost]
        public IHttpActionResult Post()
        {
            try
            {
                string postdata = Request.Content.ReadAsStringAsync().Result;
                var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

                if (eventobj.Events[0].Type == "message")
                {
                    ReplyMsg botreply = new ReplyMsg(_accesstoken);

                    Ticket myticket;
                    List<string> msglist;

                    if (eventobj.Events[0].Message.Text == "訂車票")
                    {
                        myticket = new Ticket();
                        HttpContext.Current.Application["ticket"] = myticket;
                        msglist = TickerConversation.Process(ref myticket, "");
                    }
                    else
                    {
                        myticket = (Ticket)HttpContext.Current.Application["ticket"];
                        msglist = TickerConversation.Process(ref myticket, eventobj.Events[0].Message.Text);
                    }

                    var replymsg = new TextMessageObj();

                    if (msglist.Count > 0)
                    {
                        HttpContext.Current.Application["ticket"] = myticket;
                        replymsg.Text = msglist[0];
                    }
                    else
                    {
                        replymsg.Text = string.Format("這是您的車票訂購資訊，{0}日從{1}出發到{2}的車票{3}張"
                            , myticket.Day.Value
                            , myticket.From
                            , myticket.To
                            , myticket.Cnt);
                    }
                    botreply.Send(eventobj.Events[0].ReplyToken, replymsg);

                }
                return Ok();
            }
            catch (Exception)
            {
                return Ok();
            }

        }
       */

    }
}
