﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RedisApp.Models
{
    public static class Helper
    {
        private static Lazy<ConnectionMultiplexer> lazyConnection = new Lazy<ConnectionMultiplexer>(() =>
        {
            return ConnectionMultiplexer.Connect("redis0129.redis.cache.windows.net:6380,password=l5xaztHA1aUqolefrmnXxaDZZpXIUNYdsPpMlQlAJts=,ssl=True,abortConnect=False");
        });
        public static ConnectionMultiplexer Connection
        {
            get
            {
                return lazyConnection.Value;
            }
        }
    }
}