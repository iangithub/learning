﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RedisApp.Models;

namespace RedisApp.Controllers
{
    public class TestRedisController : Controller
    {
        // GET: TestRedis
        public ActionResult Index()
        {
            //設定連線字串
            ConnectionMultiplexer connection = ConnectionMultiplexer.Connect("redis0129.redis.cache.windows.net:6380,password=l5xaztHA1aUqolefrmnXxaDZZpXIUNYdsPpMlQlAJts=,ssl=True,abortConnect=False");
            IDatabase cache = connection.GetDatabase();

            if (connection.IsConnected)
            {
                //存入快取資料
                cache.StringSet("Org", "Azure Redis Cache");

                //由快取取得資料
                ViewData["Org"] = cache.StringGet("Org");
            }

            return View();
        }

        private static void Log()
        {
            ConnectionMultiplexer connection = Helper.Connection;
            ISubscriber subscriber = connection.GetSubscriber();
            subscriber.Subscribe("__keyspace@0__:*", (channel, notificationtype) =>
            {
                var key = GetKey(channel);
                switch (notificationtype)
                {
                    case "rename_to": // requires the "Kg" keyspace notification option
                        // Do stuff .....
                        //ex: Log("rename_to: " + key);
                        break;
                    case "rename_from": // requires the "Kg" keyspace notification option
                        // Do stuff .....
                        //ex: Log("rename_from: " + key);
                        break;
                    case "del": // requires the "Kg" keyspace notification option to be enabled
                        // Do stuff .....
                        //ex: Log("del: " + key);
                        break;
                }
            });
        }
        private static string GetKey(string channel)
        {
            var index = channel.IndexOf(':');
            if (index >= 0 && index < channel.Length - 1)
                return channel.Substring(index + 1);
            
            return channel;
        }
    }
}