﻿using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LuisUseSDK
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User: > ");
            string userstr = Console.ReadLine();

            while (userstr != "quit")
            {
                var result = LuisService(userstr).GetAwaiter().GetResult();

                if (result != null)
                {
                    Console.WriteLine("Intent : " + result.TopScoringIntent.Intent);

                    foreach (var item in result.Entities)
                    {
                        Console.WriteLine("Entities : " + item.Entity);
                        Console.WriteLine("Entities Type: " + item.Type);

                        item.AdditionalProperties.TryGetValue("role", out object val);
                        if (val != null)
                        {
                            Console.WriteLine("Entities Role: " + (string)val);
                        }
                    }

                    foreach (var item in result.CompositeEntities)
                    {
                        Console.WriteLine("CompositeEntities ParentType: " + item.ParentType);
                        Console.WriteLine("CompositeEntities Value: " + item.Value);

                        foreach (var childitem in item.Children)
                        {
                            Console.WriteLine("childitem type: " + childitem.Type);
                            Console.WriteLine("childitem value: " + childitem.Value);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("無法提供服務");

                }

                Console.Write("Enter >: ");
                userstr = Console.ReadLine();
            }
        }

        static async Task<LuisResult> LuisService(string qstr)
        {
            var luisappid = "your luis app id";
            var luiskey = "your luis auth key";
            var credentials = new ApiKeyServiceClientCredentials(luiskey);
            var luisclient = new LUISRuntimeClient(credentials, new System.Net.Http.DelegatingHandler[] { });
            luisclient.Endpoint = "https://westus.api.cognitive.microsoft.com";

            // common settings for remaining parameters
            Double? timezoneoffset = null;
            var verbose = true;
            var staging = false;
            var spellCheck = false;
            String bingspellcheckkey = null;
            var log = false;

            // Create prediction client
            var prediction = new Prediction(luisclient);
            return await prediction.ResolveAsync(luisappid, qstr, timezoneoffset, verbose, staging, spellCheck, bingspellcheckkey, log, CancellationToken.None);
        }
    }
}
