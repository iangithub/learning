﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.DataView;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace MLRegressionCore
{
    class Program
    {
        static readonly string _trainDataPath =
            Path.Combine(Environment.CurrentDirectory, "Data", "ubike.csv");

        static readonly string _testDataPath =
            Path.Combine(Environment.CurrentDirectory, "Data", "ubiketest.csv");

        static readonly string _modelPath =
            Path.Combine(Environment.CurrentDirectory, "Data", "Model.zip");

        static void Main(string[] args)
        {
            MLContext mlContext = new MLContext();

            var model = Train(mlContext, _trainDataPath);
            Evaluate(mlContext, model);
        }

        public static ITransformer Train(MLContext mlContext, string dataPath)
        {
            IDataView dataView = mlContext.Data.LoadFromTextFile<Ubike>(dataPath, hasHeader: true, separatorChar: ',');
            /*
             * Transforms.CopyColumns 要預測的欄位
             * Transforms.OneHotEncodingEstimator 訓練模型的算法需要數字特徵，使用OneHotEncodingEstimator轉換
             * Transforms.Concatenate 指出特徵資料
             * Regression.Trainers.FastTree 選擇學習演算法
             */
            var pipeline = mlContext.Transforms.CopyColumns(outputColumnName: "Label", inputColumnName: "Sbi")
                    .Append(mlContext.Transforms.Categorical.OneHotEncoding(outputColumnName: "SiteCodeEncoded", inputColumnName: "SiteCode"))
                    .Append(mlContext.Transforms.Categorical.OneHotEncoding(outputColumnName: "MdayEncoded", inputColumnName: "Mday"))
                    .Append(mlContext.Transforms.Categorical.OneHotEncoding(outputColumnName: "TotalEncoded", inputColumnName: "Total"))
                    .Append(mlContext.Transforms.Categorical.OneHotEncoding(outputColumnName: "BempEncoded", inputColumnName: "Bemp"))
                    .Append(mlContext.Transforms.Concatenate("Features", "SiteCodeEncoded", "MdayEncoded", "TotalEncoded", "BempEncoded"))
                    .Append(mlContext.Regression.Trainers.FastTree());

            //Train the model
            var model = pipeline.Fit(dataView);

            SaveModelAsFile(mlContext, model);
            return model;
        }

        private static void Evaluate(MLContext mlContext, ITransformer model)
        {
            IDataView dataView = mlContext.Data.LoadFromTextFile<Ubike>(_testDataPath, hasHeader: true, separatorChar: ',');

            var predictions = model.Transform(dataView);
           
            var metrics = mlContext.Regression.Evaluate(predictions, "Label", "Score");
           

            Console.WriteLine();
            Console.WriteLine($"*------------ Model quality metrics evaluation ---------------");
            Console.WriteLine($"RSquared Score(0~1 愈趨近1愈好):      {metrics.RSquared:0.##}");
            Console.WriteLine($"RMS loss(值愈小愈好):      {metrics.Rms:#.##}");
        }

        private static void SaveModelAsFile(MLContext mlContext, ITransformer model)
        {
            using (var fileStream = new FileStream(_modelPath, FileMode.Create, FileAccess.Write, FileShare.Write))
                mlContext.Model.Save(model, fileStream);
        }
    }
}
