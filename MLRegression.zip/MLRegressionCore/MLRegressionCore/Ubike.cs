﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ML.Data;

namespace MLRegressionCore
{
    public class Ubike
    {
        [LoadColumn(0)]
        public string SiteCode;
        [LoadColumn(1)]
        public string SiteName;
        /// <summary>
        /// 總停車格
        /// </summary>
        [LoadColumn(2)]
        public float Total;
        /// <summary>
        /// 可借數
        /// </summary>
        [LoadColumn(3)]
        public float Sbi;
        [LoadColumn(4)]
        public DateTime Mday;
        /// <summary>
        /// 可還數
        /// </summary>
        [LoadColumn(5)]
        public float Bemp;
    }

    public class UbikePrediction
    {
        [ColumnName("Score")]
        public float SbiPrediction;
    }
}