﻿using Microsoft.ML;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLRegressionApp
{
    class Program
    {
        static readonly string _modelPath = Environment.CurrentDirectory + "/Model.zip";

        static void Main(string[] args)
        {
            MLContext mlContext = new MLContext();
            TestPrediction(mlContext);
        }

        private static void TestPrediction(MLContext mlContext)
        {
            //load the model
            ITransformer loadedModel;
            using (var stream = new FileStream(_modelPath, FileMode.Open
                , FileAccess.Read, FileShare.Read))
            {
                loadedModel = mlContext.Model.Load(stream);
            }

            //Prediction test
            //Create prediction function and make prediction.
            var predictionFunction = loadedModel.CreatePredictionEngine<Ubike, UbikePrediction>(mlContext);
            
            //Test Sample Data
            var sampledata = new Ubike()
            {
                SiteCode = "1001",
                SiteName = "大鵬華城",
                Total = 38,
                Sbi = 0, // To predict
                Mday = DateTime.Parse("2018/11/13 23:00:00"),
                Bemp = 27
            };

            var prediction = predictionFunction.Predict(sampledata);

            Console.WriteLine($"Predicted fare: {prediction.SbiPrediction:0.####}");

        }
    }
}
