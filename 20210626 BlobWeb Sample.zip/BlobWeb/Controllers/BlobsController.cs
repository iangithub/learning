﻿using Azure.Storage;
using Azure.Storage.Blobs;
using Azure.Storage.Sas;
using Microsoft.Azure;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BlobWeb.Controllers
{
    public class BlobsController : Controller
    {
        // GET: Blobs
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult UploadBlob(HttpPostedFileBase file)
        {
            TempData["actionmessage"] = "Load Fail";
            if (file != null)
            {
                if (file.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var container = GetCloudBlobContainerClient();
                    var blobClient = container.GetBlobClient(Guid.NewGuid() + fileName);
                    using (var fileStream = file.InputStream)
                    {
                        blobClient.Upload(fileStream, true);
                    }
                    TempData["actionmessage"] = "Load Success";
                }
            }
            return RedirectToAction("Index");
        }

        public ActionResult ListBlobs()
        {
            var container = GetCloudBlobContainerClient();
            var bloblItems = new List<BlobWeb.Models.BlobItem>();

            foreach (var item in container.GetBlobs())
            {
                var downloadUri = SasAuthAsync(item.Name);
                bloblItems.Add(
                    new Models.BlobItem()
                    {
                        FileName = item.Name,
                        Uri = downloadUri
                    }
                );
            }
            return View(bloblItems);
        }


        public ActionResult DownloadBlob(string filename)
        {
            var container = GetCloudBlobContainerClient();
            var blobClient = container.GetBlobClient(filename);
            var download = blobClient.DownloadAsync().GetAwaiter().GetResult();
            var contentType = download.Value.ContentType;
            return new FileStreamResult(download.Value.Content, contentType);
        }

        public ActionResult DeleteBlob(string filename)
        {
            var container = GetCloudBlobContainerClient();
            var blobClient = container.GetBlobClient(filename);
            blobClient.Delete();

            return RedirectToAction("ListBlobs");
        }

        private BlobContainerClient GetCloudBlobContainerClient()
        {
            var blobServiceClient =
                new BlobServiceClient(
                    CloudConfigurationManager.GetSetting("AzureBlobConnectionString")
                    );

            var containerClient = blobServiceClient.GetBlobContainerClient("pic");

            return containerClient;
        }


        private string SasAuthAsync(string filename)
        {
            var sas = new AccountSasBuilder
            {
                Services = AccountSasServices.Blobs,
                ResourceTypes = AccountSasResourceTypes.Object,
                ExpiresOn = DateTime.Now.AddSeconds(5)
            };

            sas.SetPermissions(AccountSasPermissions.Read);

            StorageSharedKeyCredential credential = new StorageSharedKeyCredential("儲存體帳戶名稱", "儲存體帳戶授權Key");

            var sasUri = new UriBuilder($"https://儲存體帳戶名稱.blob.core.windows.net/容器名稱/{filename}");
            sasUri.Query = sas.ToSasQueryParameters(credential).ToString();

            BlobServiceClient blobServiceClient = new BlobServiceClient(sasUri.Uri);
            return blobServiceClient.Uri.ToString();
        }
    }
}