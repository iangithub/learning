﻿using Microsoft.Azure.CognitiveServices.Vision.Face;
using Microsoft.Azure.CognitiveServices.Vision.Face.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FaceApiConsoleApp
{
    class Program
    {
        private const string subscriptionKey = "07b710aec2bb495d8138764305f0d09c";
        private const string endpoint = "https://eastus.api.cognitive.microsoft.com/";

        private static readonly FaceAttributeType[] faceAttributes 
            = { FaceAttributeType.Age, FaceAttributeType.Gender, FaceAttributeType.Emotion };

        private const string imgfile = "faceimg/2.jpg";

        static async Task Main(string[] args)
        {
            FaceClient faceClient = new FaceClient(
                new ApiKeyServiceClientCredentials(subscriptionKey),
                new System.Net.Http.DelegatingHandler[] { });

            faceClient.Endpoint = endpoint;

            Console.WriteLine("臉部辨識中 ...");

            await DetectLocalAsync(faceClient);

            Console.ReadLine();
        }

        static async Task DetectLocalAsync(FaceClient faceClient)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    using (Stream imgstream = File.OpenRead(imgfile))
                    {
                        IList<DetectedFace> faceList 
                            = await faceClient.Face.DetectWithStreamAsync(imgstream, true, false, faceAttributes);

                        var faceinfo = string.Empty;
                        foreach (DetectedFace face in faceList)
                        {
                            faceinfo += "FaceID:" + face.FaceId
                                + " / Age:" + face.FaceAttributes.Age
                                + " / Gender:" + face.FaceAttributes.Gender.ToString()
                                + " / Emotion Happiness:" + face.FaceAttributes.Emotion.Happiness.ToString()
                                + " / Left:" + face.FaceRectangle.Left
                                + " / Top:" + face.FaceRectangle.Top
                                + " / Width:" + face.FaceRectangle.Width
                                + " / Height:" + face.FaceRectangle.Height;
                        }
                        Console.WriteLine(faceinfo);
                    }
                }
                catch (APIErrorException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            else
            {
                Console.WriteLine("No file !!");
            }
        }
    }
}
