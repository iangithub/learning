﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace QAmakerConsoleApp
{
    class Program
    {
        static async Task Main(string[] args)
        {
            AnswerResult result = new AnswerResult();

            var question = new Question()
            {
                QuestionStr = "請問有停車場嗎",
                Top = 1
            };
                       
            //string url = "https://ianqademo1.azurewebsites.net/qnamaker/knowledgebases/43bcf264-85df-4a42-babd-f76a484a1e66/generateAnswer";
            //string endpoint_key = "9d0f9825-c740-40a6-8ac4-9d5898eaa4ce";

            string url = "https://qnamkdemo1.azurewebsites.net/qnamaker/knowledgebases/886a86ec-c713-458e-aec5-57d6d084b567/generateAnswer";
            string endpoint_key = "07eb20d9-0e09-4a16-b8c7-7f0005b5c09f";

            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage())
                {
                    request.Method = HttpMethod.Post;
                    request.RequestUri = new Uri(url);
                    request.Headers.Add("Authorization", "EndpointKey " 
                        + endpoint_key);

                    request.Content = new StringContent(
                        JsonConvert.SerializeObject(question)
                        , Encoding.UTF8, "application/json");

                    var response = await client.SendAsync(request);

                    var val = await response.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<AnswerResult>(val);
                }
            }

            Console.WriteLine(result.Answers[0].AnswerStr);
        }
    }
}
