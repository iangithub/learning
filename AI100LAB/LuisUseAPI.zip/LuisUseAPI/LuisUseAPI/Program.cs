﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace LuisUseAPI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("User: > ");
            string userstr = Console.ReadLine();

            while (userstr != "quit")
            {
                var result = LuisService(userstr).GetAwaiter().GetResult();

                if (result != null)
                {
                    Console.WriteLine("Intent : " + result.TopScoringIntent.Intent);

                    foreach (var item in result.Entities)
                    {
                        Console.WriteLine("Entities : " + item.EntityItem);
                        Console.WriteLine("Entities Type: " + item.Type);
                    }
                }
                else
                {
                    Console.WriteLine("無法提供服務");
                }

                Console.Write("Enter >: ");
                userstr = Console.ReadLine();
            }
        }

        private static async Task<LuisResult> LuisService(string usertalk)
        {
            var result = new LuisResult();

            var querystr = HttpUtility.ParseQueryString(string.Empty);
            var luisappid = "119c740d-09f4-4ff5-a4ee-576dde9d0309";
            var subscriptionkey = "55d5d194e72845e983ecc9ad0b6481ea";
            var endpoint = "https://australiaeast.api.cognitive.microsoft.com/luis/v2.0/apps/" + luisappid + "?";

            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage())
            {

                // Request parameters
                querystr["verbose"] = "true"; //需要回傳的所有 Intent ，將 verbose 設定為 true
                querystr["q"] = usertalk;
                querystr["spellCheck"] = "false";
                querystr["staging"] = "false";
                querystr["log"] = "true";

                request.Method = HttpMethod.Get;
                request.RequestUri = new Uri(endpoint + querystr);
                request.Headers.Add("Ocp-Apim-Subscription-Key", subscriptionkey);

                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();
                result = JsonConvert.DeserializeObject<LuisResult>(responseBody);

            }

            return result;
        }
    }
}
