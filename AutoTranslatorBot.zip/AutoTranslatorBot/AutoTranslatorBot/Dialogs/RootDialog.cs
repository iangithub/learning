﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AutoTranslatorBot.Models;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;

namespace AutoTranslatorBot.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        Dictionary<string, string> _supportlang = new Dictionary<string, string>() {
            { "中文", "zh-Hant"},
            { "英文", "en"},
            { "日文", "ja"},
            { "韓文", "ko"}
        };

        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;
            string lang = "en"; //預設翻譯為英文

            if (activity.Text.Trim() == "/help")
            {
                await context.PostAsync("我可以幫你翻譯喔，預設翻譯為英文，若要切換語言，請輸入 /語言 指令，例如　/英文　或　/日文");
            }
            else
            {
                //使用者輸入指令切換語系
                if (activity.Text.Trim().StartsWith("/"))
                {
                    var userlang = "en";
                    if (_supportlang.ContainsKey(activity.Text.Trim().Replace("/", "")))
                    {
                        userlang = _supportlang[activity.Text.Trim().Replace("/", "")];
                        context.UserData.SetValue("userlang", userlang);
                        await context.PostAsync($"好的，後續將開始幫您翻譯成{activity.Text.Trim().Replace("/", "")}");
                    }
                    else
                    {
                        await context.PostAsync("很抱歉目前尚未支援您所需要的語言");
                    }
                }
                else
                {
                    string replystr = string.Empty; //回覆訊息
                    //取得使用者設定的語系
                    if (context.UserData.TryGetValue("userlang", out lang))
                    {
                        replystr = await TranslateService(activity.Text, lang);
                    }
                    else
                    {
                        replystr = await TranslateService(activity.Text, "en");
                    }

                    await context.PostAsync(replystr);
                }
            }
            context.Wait(MessageReceivedAsync);
        }

        private async Task<string> TranslateService(string talkword, string lang)
        {
            string result = string.Empty;
            string host = "https://api.cognitive.microsofttranslator.com";
            string path = "/translate?api-version=3.0";
            string paras = "&to=" + lang;
            paras += "&category=generalnn";
            //Get from Azure
            string key = "9953313596c64323af2f0fc0de51b404";
            string uri = host + path + paras;

            System.Object[] body = new System.Object[] { new { Text = talkword } };
            var requestBody = JsonConvert.SerializeObject(body);

            using (var client = new HttpClient())
            using (var request = new HttpRequestMessage())
            {
                request.Method = HttpMethod.Post;
                request.RequestUri = new Uri(uri);
                request.Content = new StringContent(requestBody, Encoding.UTF8, "application/json");
                request.Headers.Add("Ocp-Apim-Subscription-Key", key);

                var response = await client.SendAsync(request);
                var responseBody = await response.Content.ReadAsStringAsync();
                List<Translation> tranresult = JsonConvert.DeserializeObject<List<Translation>>(responseBody);
                result = tranresult[0].Translations[0].Text;
            }
            return result;
        }
    }
}