﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace SqlDatabase
{
    public partial class GridView : System.Web.UI.Page
    {
        string _connstr = ConfigurationManager.ConnectionStrings["AzureSqlConnStr"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        private void LoadData()
        {
            using (SqlConnection conn = new SqlConnection(_connstr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = @"select id,name,empno from employees order by empno";
                    cmd.Connection = conn;
                    cmd.Connection.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    this.GridView1.DataSource = dr;
                    this.GridView1.DataBind();
                    cmd.Connection.Close();
                }
            }
        }

        protected void Add_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(_connstr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = @"insert into employees (id,name,empno,title)
values (newid(),@name,@empno,@title)";
                    cmd.Parameters.Add("@name", SqlDbType.NVarChar).Value = this.Name.Text;
                    cmd.Parameters.Add("@empno", SqlDbType.NVarChar).Value = this.Empno.Text;
                    cmd.Parameters.Add("@title", SqlDbType.NVarChar).Value = this.Title.Text;
                    cmd.Connection = conn;
                    cmd.Connection.Open();
                    cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
            }
            LoadData();
        }
    }
}