﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace cosmosdb.Models
{
    using Microsoft.Azure.Documents;
    using Newtonsoft.Json;
    using System.ComponentModel.DataAnnotations;

    public class Item
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        [Required]
        [JsonProperty(PropertyName = "year")]
        public string Year { get; set; }
        [Required]
        [JsonProperty(PropertyName = "date")]
        public string Date { get; set; }
        [Required]
        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }
        [Required]
        [JsonProperty(PropertyName = "desc")]
        public string Desc { get; set; }
        [JsonProperty(PropertyName = "IsComplete")]
        public string IsComplete { get; set; }
    }
}