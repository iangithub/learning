// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.5.0

using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using BankBot.Models;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime;
using Microsoft.Azure.CognitiveServices.Language.LUIS.Runtime.Models;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using Newtonsoft.Json.Linq;

namespace BankBot.Bots
{
    public class EchoBot : ActivityHandler
    {

        private static CurrencyInfo _currencyInfo = new CurrencyInfo();

        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            var replymsg = "�L�k���ѪA��";

            if (!string.IsNullOrEmpty(turnContext.Activity.Text))
            {
                var luisresult = LuisService(turnContext.Activity.Text).GetAwaiter().GetResult();

                if (luisresult != null)
                {
                    if (luisresult.TopScoringIntent.Intent == "�ײv�d��")
                    {
                        JObject jobj = JObject.Parse(luisresult.Entities[0]
                            .AdditionalProperties["resolution"].ToString());

                        dynamic dynaobj = jobj as dynamic;

                        replymsg = await FeedbackCurrencyRate((string)dynaobj.values[0]);
                    }
                }
            }
            
            await turnContext.SendActivityAsync(MessageFactory.Text(replymsg), cancellationToken);
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text($"Hello and welcome!"), cancellationToken);
                }
            }
        }

        static async Task<LuisResult> LuisService(string qstr)
        {
            var luisappid = "your luis app id";
            var luiskey = "your luis key";
            var credentials = new ApiKeyServiceClientCredentials(luiskey);
            var luisclient = new LUISRuntimeClient(credentials, new System.Net.Http.DelegatingHandler[] { });
            luisclient.Endpoint = "https://westus.api.cognitive.microsoft.com";

            // common settings for remaining parameters
            Double? timezoneoffset = null;
            var verbose = true;
            var staging = false;
            var spellCheck = false;
            String bingspellcheckkey = null;
            var log = false;

            // Create prediction client
            var prediction = new Prediction(luisclient);
            return await prediction.ResolveAsync(luisappid, qstr, timezoneoffset, verbose, staging, spellCheck, bingspellcheckkey, log, CancellationToken.None);
        }

        private static async Task<string> FeedbackCurrencyRate(string currency)
        {

            string result = @"�z�߰ݪ����O{0}�ثe�ײv
�{�r�R�J{1}�A��X {2}
�Y���R�J{3}�A��X{4}
�H�W�ײv�Ӧۥx�Ȥ��i�ײv��T�ȨѰѦҡA�ХH��کӧ@�ײv���D�C ";

            //��X���O�ײv
            await FindCurrencyRate();

            if (_currencyInfo != null)
            {
                var item = _currencyInfo.Rates.Find(x => x.CurrencyType == currency);
                if (item != null)
                {
                    result = string.Format(result, currency, item.BuyCash
                        , item.SellCash, item.BuySpot, item.SellSpot);
                }
                else
                {
                    result = "�L�k���ѳo�ӹ��O����T";
                }
            }

            return result;
        }

        //��X���O�ײv
        private static async Task FindCurrencyRate()
        {
            //�O����S������ײv��T
            if (_currencyInfo.Rates == null)
            {
                await DownloadCurrency();
                _currencyInfo.LastTime = DateTime.Now;
            }
            else
            {
                //�O����Ȧs���ײv��T�W�L1�p�ɡA���s��s
                if (_currencyInfo.LastTime.Hour < DateTime.Now.Hour || _currencyInfo.LastTime.Date < DateTime.Now.Date)
                {
                    if (_currencyInfo.Rates != null)
                    {
                        _currencyInfo.Rates.Clear();
                    }
                    await DownloadCurrency();
                    _currencyInfo.LastTime = DateTime.Now;
                }
            }
        }

        //�U���ײv��T
        private static async Task DownloadCurrency()
        {
            var line = string.Empty;
            _currencyInfo.Rates = new System.Collections.Generic.List<CurrencyRate>();

            using (var client = new HttpClient())
            {
                using (var response = await client.GetAsync("https://rate.bot.com.tw/xrt/flcsv/0/day"))
                {
                    using (Stream st = await response.Content.ReadAsStreamAsync())
                    {
                        using (var streader = new StreamReader(st))
                        {
                            var i = 0;
                            while ((line = streader.ReadLine()) != null)
                            {
                                string[] split = line.Split(',');
                                if (i > 0)
                                {
                                    var item = new CurrencyRate();
                                    item.CurrencyType = split[0];
                                    item.BuyCash = decimal.Parse(split[2]);
                                    item.BuySpot = decimal.Parse(split[3]);
                                    item.SellCash = decimal.Parse(split[12]);
                                    item.SellSpot = decimal.Parse(split[13]);
                                    _currencyInfo.Rates.Add(item);
                                }
                                i++;
                            }
                        }
                    }
                }
            }
        }
    }
}
