﻿
public class LuisResult
{
    public string query { get; set; }
    public Prediction prediction { get; set; }
}

public class Prediction
{
    public string topIntent { get; set; }
    public Intents intents { get; set; }
    public Entities entities { get; set; }
}

public class Intents
{
    public 詢問旅遊 詢問旅遊 { get; set; }
    public None None { get; set; }
    public 客訴 客訴 { get; set; }
}

public class 詢問旅遊
{
    public float score { get; set; }
}

public class None
{
    public float score { get; set; }
}

public class 客訴
{
    public float score { get; set; }
}

public class Entities
{
    public string[] 城市 { get; set; }
    public Instance instance { get; set; }
}

public class Instance
{
    public 城市[] 城市 { get; set; }
}

public class 城市
{
    public string type { get; set; }
    public string text { get; set; }
    public int startIndex { get; set; }
    public int length { get; set; }
    public float score { get; set; }
    public int modelTypeId { get; set; }
    public string modelType { get; set; }
    public string[] recognitionSources { get; set; }
}
