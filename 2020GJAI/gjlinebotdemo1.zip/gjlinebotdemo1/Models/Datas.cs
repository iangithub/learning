﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace gjlinebotdemo1.Models
{
    public static class Datas
    {
        public static List<Travel> QueryTravel()
        {
            var result = new List<Travel>();

            var Travel = new Travel()
            {
                Title = "北海道保住一晚ClubMed.雲海纜車",
                No = "T001",
                Price = 87900,
                DescContent = "北海道保住一晚ClubMed.雲海纜車.富田農場.DIY.旭山動物園.函館夜景.三大蟹溫泉五日【千/函】",
                Countrys = new List<Country>(){
                                new Country(){Code="C001",Name="日本"}
                            },
                Locations = new List<Location>(){
                                new Location(){Code="L001",Name="北海道"},
                                new Location(){Code="L002",Name="函館"},
                            }
            };
            var Travel2 = new Travel()
            {
                Title = "親子京阪神",
                No = "T002",
                Price = 87900,
                DescContent = "親子京阪神.海遊館＋摩天輪.觀光船聖瑪麗亞號.神戶動物王國.環球影城.DIY音樂盒五日(贈四項快速劵)】",
                Countrys = new List<Country>(){
                                new Country(){Code="C001",Name="日本"}
                            },
                Locations = new List<Location>(){
                                new Location(){Code="L001",Name="京都"},
                                new Location(){Code="L002",Name="阪神"},
                            }
            };
            var Travel3 = new Travel()
            {
                Title = "經典加東楓采10日",
                No = "T003",
                Price = 107900,
                DescContent = "賞楓雙纜車．雙遊船．尼加拉面瀑房．聖安妮渡假村．川普朗渡假村．阿岡昆．魁北克．尼加拉品酒",
                Countrys = new List<Country>(){
                                new Country(){Code="C001",Name="加拿大"}
                            },
                Locations = new List<Location>(){
                                new Location(){Code="L001",Name="魁北克"},
                                new Location(){Code="L002",Name="阿岡昆"},
                            }
            };

            result.Add(Travel);
            result.Add(Travel2);
            result.Add(Travel3);

            return result;
        }
    }
}