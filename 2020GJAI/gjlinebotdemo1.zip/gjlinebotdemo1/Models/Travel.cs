﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace gjlinebotdemo1.Models
{
    public class Member
    {
        public string No { get; set; }
        public string Name { get; set; }
        public string Idno { get; set; }
        public string Mobile { get; set; }

        public List<Order> Orders { get; set; }
    }

    public class Order
    {
        public string MemberNo { get; set; }
        public Travel Travel { get; set; }

        public int Price { get; set; }

        public DateTime Date { get; set; }
    }

    public class Travel
    {
        public string No { get; set; }
        public string Title { get; set; }
        public string DescContent { get; set; }
        public int Price { get; set; }
        public List<Country> Countrys { get; set; }
        public List<Location> Locations { get; set; }
    }

    public class Country
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public class Location
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}