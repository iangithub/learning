﻿using Microsoft.Ajax.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Web;

namespace gjlinebotdemo1.Models
{
    public class QueryOrder
    {
        public QueryOrder()
        {
            this.Status = 0;
        }

        public string IdNo { get; set; }
        public string MobileNo { get; set; }
        public string MemberNo { get; set; }
        /// <summary>
        /// 對話物件的狀態
        /// </summary>
        public int Status { get; internal set; }

    }

    public static class QueryOrderConversation
    {
        public static List<string> Process(ref QueryOrder order, string val)
        {
            var result = new List<string>();

            if (order == null)
            {
                throw new Exception("Query Can't be null");
            }

            switch (order.Status)
            {
                case 1:
                    order.IdNo = val;
                    break;
                case 2:
                    order.MobileNo = val;
                    break;
                case 3:
                    order.MemberNo = val;
                    break;
                default:
                    break;
            }

            if (string.IsNullOrEmpty(order.IdNo))
            {
                result.Add("您的身份字號末4碼是?");
                order.Status = 1;
            }
            else if (string.IsNullOrEmpty(order.MobileNo))
            {
                result.Add("您的手機末4碼是?");
                order.Status = 2;
            }
            else if (string.IsNullOrEmpty(order.MemberNo))
            {
                result.Add("您的會員編號是?");
                order.Status = 3;
            }

            return result;
        }
    }
}