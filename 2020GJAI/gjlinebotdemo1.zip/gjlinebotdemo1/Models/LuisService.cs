﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace gjlinebotdemo1.Models
{
    public static class LuisService
    {
        public static async Task<LuisResult> MakeRequest(string userquery)
        {
            var client = new HttpClient();
            var queryString = HttpUtility.ParseQueryString(string.Empty);

            var subscription_key = "1e23d9416a31416eb1cb7d79d6939eb5";
            var appId = "1c28f032-5b23-499e-a14e-f03be437ac51";
            var uri = $"https://linebotluisdemo1.cognitiveservices.azure.com/luis/prediction/v3.0/apps/{appId}/slots/production/predict?subscription-key={subscription_key}&verbose=true&show-all-intents=true&log=true&query={userquery}";
            var response = await client.GetAsync(uri);

            var strResponseContent = await response.Content.ReadAsStringAsync();

            var result = JsonConvert.DeserializeObject<LuisResult>(strResponseContent.ToString());

            return result;
        }
    }
}