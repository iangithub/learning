﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;

using CodeFunLinebot.LineBotService;
using CodeFunLinebot.LineEvent;
using Newtonsoft.Json;
using CodeFunLinebot.TemplateMessage;
using gjlinebotdemo1.Models;
using CodeFunLinebot.LineMessage;
using CodeFunLinebot.TemplateMessage.Action;

namespace gjlinebotdemo1.Controllers
{
    public class MyLineBotDemoController : ApiController
    {
        private readonly string _accesstoken = @"your line app access token";

        public async Task<IHttpActionResult> Post()
        {
            string postdata = Request.Content.ReadAsStringAsync().Result;
            var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

            var dmdatas = Datas.QueryTravel();

            ReplyMsg botreply = new ReplyMsg(_accesstoken);
            List<CodeFunLinebot.SendReplyMsg.Message> msgs =
                new List<CodeFunLinebot.SendReplyMsg.Message>();

            try
            {
                if (eventobj.Events[0].Type == "message")
                {
                    var replymsg = new List<CarouselColumnObject>();

                    var result = await LuisService.MakeRequest(eventobj.Events[0].Message.Text);

                    //botreply.Send(eventobj.Events[0].ReplyToken
                    //                       , new TextMessageObj() { Text = result.prediction.topIntent });

                    switch (result.prediction.topIntent)
                    {
                        case "詢問旅遊":
                            //抓國家或城市,區域
                            var citys = result.prediction.entities.目的地;

                            foreach (var c in citys)
                            {
                                foreach (var item in dmdatas)
                                {
                                    var lc = item.Locations.Find(x => x.Name == c);

                                    if (lc !=  null)
                                    {
                                        var card = new CarouselColumnObject();
                                        card.Title = lc.Name;
                                        card.Text = item.DescContent;
                                        card.ThumbnailImageUrl = "https://static.liontech.com.tw/ConsoleAPData/PublicationStatic/lion_tw_b2c/zh-tw/_ModelFile/PictureAndText/17136/8338a612e9be425fa5c5a635d3782f74.jpg?fr=cg734T0301C0101M01";
                                        card.Actions = new List<TemplateMessageActionBase>() {
                                        new UriAction(){Uri=$"https://travel.liontravel.com/detail?NormGroupID=eedc1e66-84fa-4ad1-b88f-658c1e1596fd&GroupID=20TN612CUI-B&fr=cg734T0301C0101M01",Label="報名去"}
                                        ,new UriAction(){Uri="https://travel.liontravel.com/detail?NormGroupID=eedc1e66-84fa-4ad1-b88f-658c1e1596fd&GroupID=20TN612CUI-B&fr=cg734T0301C0101M01",Label="詳細資訊"}
                                    };

                                        replymsg.Add(card);
                                    }

                                }
                            }

                            break;
                        case "客訴":
                            break;
                        default:
                            botreply.Send(eventobj.Events[0].ReplyToken
                              , new TextMessageObj() { Text = "很抱歉，我無法明白您的意思" });
                            break;
                    }

                    if (replymsg.Count > 0)
                    {
                        var template = new CarouselTemplateObject()
                        {
                            Columns = replymsg,
                        };
                        botreply.Send(eventobj.Events[0].ReplyToken, template, "請至手機確認訊息");
                    }
                    else
                    {
                        botreply.Send(eventobj.Events[0].ReplyToken, new TextMessageObj() { Text = "抱歉，目前沒有符合的行程資料" });
                    }
                }

                return Ok();
            }
            catch (Exception)
            {
                return Ok();
            }
        }
    }
}