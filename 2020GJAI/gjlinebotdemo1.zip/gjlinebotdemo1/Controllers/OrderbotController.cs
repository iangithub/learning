﻿using CodeFunLinebot.LineBotService;
using CodeFunLinebot.LineEvent;
using CodeFunLinebot.LineMessage;
using gjlinebotdemo1.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace gjlinebotdemo1.Controllers
{
    public class OrderbotController : ApiController
    {
        private readonly string _accesstoken = @"your line app access token";

        public async Task<IHttpActionResult> Post()
        {
            string postdata = Request.Content.ReadAsStringAsync().Result;
            var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

            try
            {
                ReplyMsg botreply = new ReplyMsg(_accesstoken);
                List<CodeFunLinebot.SendReplyMsg.Message> msgs = new List<CodeFunLinebot.SendReplyMsg.Message>();

                if (eventobj.Events[0].Type == "message")
                {
                    QueryOrder myorder;
                    List<string> msglist;

                    //簡化範例，實務上這裡可以使用LUIS進行語意意圖的判定
                    if (eventobj.Events[0].Message.Text == "詢問訂單")
                    {
                        myorder = new QueryOrder();
                        HttpContext.Current.Application["myorder"] = myorder;
                        msglist = QueryOrderConversation.Process(ref myorder, "");
                    }
                    else
                    {
                        myorder = (QueryOrder)HttpContext.Current.Application["myorder"];
                        msglist = QueryOrderConversation.Process(ref myorder, eventobj.Events[0].Message.Text);
                    }

                    var replymsg = new TextMessageObj();

                    if (msglist.Count > 0)
                    {
                        HttpContext.Current.Application["myorder"] = myorder;
                        replymsg.Text = msglist[0];
                    }
                    else
                    {
                        //簡化範例，實務上拿到資料應與資料庫做比對
                        if (myorder.IdNo == "9876" && myorder.MobileNo == "1234" && myorder.MemberNo == "A00112233")
                        {
                            replymsg.Text = $"這是您查詢的訂單........";
                        }
                        else
                        {
                            replymsg.Text = $"很抱歉，您的身份不正確，無法提供資料";
                        }
                    }
                    botreply.Send(eventobj.Events[0].ReplyToken, replymsg);
                }
                return Ok();
            }
            catch (Exception)
            {
                return Ok();
            }
        }
    }
}