﻿using CodeFunLinebot.LineBotService;
using CodeFunLinebot.LineEvent;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace gjlinebotdemo1.Controllers
{
    public class TemplatebotController : ApiController
    {
        private readonly string _accesstoken = @"your line app access token";

        public async Task<IHttpActionResult> Post()
        {
            string postdata = Request.Content.ReadAsStringAsync().Result;
            var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

            ReplyMsg botreply = new ReplyMsg(_accesstoken);
            List<CodeFunLinebot.SendReplyMsg.Message> msgs =
                new List<CodeFunLinebot.SendReplyMsg.Message>();

            try
            {
                if (eventobj.Events[0].Type == "message")
                {

                }
                return Ok();
            }
            catch (Exception)
            {
                return Ok();
            }
        }
    }
}