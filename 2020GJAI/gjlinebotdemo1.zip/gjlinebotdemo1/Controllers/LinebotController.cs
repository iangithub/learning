﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using CodeFunLinebot.LineBotService;
using CodeFunLinebot.LineEvent;
using CodeFunLinebot.LineMessage;
using CodeFunLinebot.TemplateMessage;
using CodeFunLinebot.TemplateMessage.Action;
using Newtonsoft.Json;

using System.Threading.Tasks;


namespace gjlinebotdemo1.Controllers
{
    public class LinebotController : ApiController
    {
        private readonly string _accesstoken = @"your line app access token";

        public async Task<IHttpActionResult> Post()
        {
            string postdata = Request.Content.ReadAsStringAsync().Result;
            var eventobj = JsonConvert.DeserializeObject<LineEventObj>(postdata);

            ReplyMsg botreply = new ReplyMsg(_accesstoken);
            List<CodeFunLinebot.SendReplyMsg.Message> msgs =
                new List<CodeFunLinebot.SendReplyMsg.Message>();

            try
            {
                if (eventobj.Events[0].Type == "message")
                {
                    //botreply.Send(eventobj.Events[0].ReplyToken
                    //    , new TextMessageObj() { Text = eventobj.Events[0].Message.Text });

                    #region reply ImageMessage

                    //List<ImageMessageObj> msgobjs = new List<ImageMessageObj>();

                    //msgobjs.Add(new ImageMessageObj()
                    //{
                    //    PreviewImageUrl = "https://static.liontech.com.tw/ConsoleAPData/PublicationStatic/lion_tw_b2c/zh-tw/_ModelFile/PictureAndText/17136/8338a612e9be425fa5c5a635d3782f74.jpg?fr=cg734T0301C0101M01",
                    //    OriginalContentUrl = "https://static.liontech.com.tw/ConsoleAPData/PublicationStatic/lion_tw_b2c/zh-tw/_ModelFile/PictureAndText/17136/8338a612e9be425fa5c5a635d3782f74.jpg?fr=cg734T0301C0101M01"
                    //});
                    //msgobjs.Add(new ImageMessageObj()
                    //{
                    //    PreviewImageUrl = "https://static.liontech.com.tw/ConsoleAPData/PublicationStatic/lion_tw_b2c/zh-tw/_ModelFile/PictureAndText/17135/4d3c9d79a03e49088e89b881fe093d6f.jpg?fr=cg734T0301C0102M01",
                    //    OriginalContentUrl = "https://static.liontech.com.tw/ConsoleAPData/PublicationStatic/lion_tw_b2c/zh-tw/_ModelFile/PictureAndText/17135/4d3c9d79a03e49088e89b881fe093d6f.jpg?fr=cg734T0301C0102M01"
                    //});

                    //botreply.Send(eventobj.Events[0].ReplyToken, msgobjs.ToArray());

                    #endregion

                    #region ButtonTemplateObject

                    var template = new ButtonTemplateObject()
                    {
                        Text = "旅行目的地",
                        Title = "請問你想去哪裡玩呢?",
                        Actions = new List<TemplateMessageActionBase>() {
                                    new PostbackAction(){Text="日本",Label="日本",Data="Japan"},
                                    new PostbackAction(){Text="韓國",Label="韓國",Data="Korea"}
                                }
                    };
                    botreply.Send(eventobj.Events[0].ReplyToken, template, "旅行目的地-想去哪裡玩");
                   
                    #endregion


                }

                return Ok();
            }
            catch (Exception)
            {
                return Ok();
            }
        }
    }
}
