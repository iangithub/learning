﻿using Microsoft.ML;
using Microsoft.ML.Trainers;
using System;
using System.IO;

namespace MovieRecommend
{
    class Program
    {
        readonly static string _trainingDataPath = Path.Combine(Environment.CurrentDirectory
                                                , "Datas"
                                                , "recommendation-ratings-train.txt");
        readonly static string _testDataPath = Path.Combine(Environment.CurrentDirectory
                                                , "Datas"
                                                , "recommendation-ratings-test.txt");
        static readonly string _modelZip = Path.Combine(Environment.CurrentDirectory
                                                , "Datas"
                                                , "recommendation.zip");

        static void Main(string[] args)
        {
            //(1) Create MLContext
            MLContext mlContext = new MLContext();

            //(2) Load training & test datasets
            IDataView trainingDataView = mlContext.Data.LoadFromTextFile<MovieRating>(_trainingDataPath
                , hasHeader: true
                , separatorChar: ',');
            IDataView testDataView = mlContext.Data.LoadFromTextFile<MovieRating>(_testDataPath
                , hasHeader: true
                , separatorChar: ',');

            //(3) Build & train model
            ITransformer model = BuildAndTrainModel(mlContext, trainingDataView);
            EvaluateModel(mlContext, testDataView, model);

            //(4) Save model
            mlContext.Model.Save(model, trainingDataView.Schema, _modelZip);
        }

        public static ITransformer BuildAndTrainModel(MLContext mlContext, IDataView trainingDataView)
        {
            /*
             userId 和 movieId 代表使用者與電影標題，而非真正的值
             使用 MapValueToKey() 方法來將每一個 userId 和 movieId 轉換成數值索引鍵類型 Feature 資料行 
             (推薦演算法所接受的格式)
             */
            IEstimator<ITransformer> estimator = mlContext
                .Transforms.Conversion.MapValueToKey(outputColumnName: "userIdEncoded"
                                                    , inputColumnName: "userId")
                .Append(mlContext.Transforms.Conversion.MapValueToKey(outputColumnName: "movieIdEncoded"
                                                    , inputColumnName: "movieId"));
            // Set algorithm options and append algorithm (MatrixFactorizationTrainer 矩陣因式分解)
            /*Matrix Factorization 演算法使用的方法稱為「共同篩選」
             * 此方法假設如果使用者 1 與使用者 2 對特定問題具有相同的意見，
             * 則使用者 1 對其他問題的想法較可能與使用者 2 相同。
             */
            var options = new MatrixFactorizationTrainer.Options
            {
                MatrixColumnIndexColumnName = "userIdEncoded",
                MatrixRowIndexColumnName = "movieIdEncoded",
                LabelColumnName = "Label",
                NumberOfIterations = 30,
                ApproximationRank = 100
            };
            var trainerEstimator = estimator.Append(mlContext.Recommendation()
                .Trainers.MatrixFactorization(options));
            // Training the model
            Console.WriteLine("=============== Training the model ===============");
            ITransformer model = trainerEstimator.Fit(trainingDataView);
            return model;
        }

        public static void EvaluateModel(MLContext mlContext, IDataView testDataView, ITransformer model)
        {
           
            Console.WriteLine("=============== Evaluating the model ===============");
            var prediction = model.Transform(testDataView);
            
            var metrics = mlContext.Regression.Evaluate(prediction, labelColumnName: "Label", scoreColumnName: "Score");
          
            Console.WriteLine("Root Mean Squared Error : " + metrics.RootMeanSquaredError.ToString());
            Console.WriteLine("RSquared: " + metrics.RSquared.ToString());
        }
    }
}
