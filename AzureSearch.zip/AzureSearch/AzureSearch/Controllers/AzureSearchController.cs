﻿using AzureSearch.Models;
using Microsoft.Azure.Search;
using Microsoft.Azure.Search.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AzureSearch.Controllers
{
    public class AzureSearchController : Controller
    {
        // GET: AzureSearch
        public ActionResult Index()
        {
            SearchParameters parameters;
            DocumentSearchResult<Goods> results;
            List<AzureSearch.Models.Goods> viewresult = new List<Goods>();

            parameters = new SearchParameters()
            {
                //Select = new[] { "Name", "Price","Remark" }
                Select = new[] { "Name" }

            };

            results = Helper.CreateSearchIndexClient().Documents.Search<Goods>("xbox one", parameters);

            foreach (var item in results.Results)
            {
                viewresult.Add((Goods)item.Document);
            }

            return View(viewresult);
        }

        public ActionResult FilterCity()
        {
            SearchParameters parameters;
            DocumentSearchResult<Goods> results;
            List<AzureSearch.Models.Goods> viewresult = new List<Goods>();

            parameters = new SearchParameters()
            {
                Filter = "price le 10000",
                //Select = new[] { "name", "price", "remark" }
                Select = new[] { "Name" }
            };

            results = Helper.CreateSearchIndexClient().Documents.Search<Goods>("xbox one", parameters);
            foreach (var item in results.Results)
            {
                viewresult.Add((Goods)item.Document);
            }

            return View("Index", viewresult);
        }
    }
}