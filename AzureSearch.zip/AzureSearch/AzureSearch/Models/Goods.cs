﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AzureSearch.Models
{
    public class Goods
    {
        //[JsonProperty(PropertyName = "name")]
        public String Name { get; set; }
        //[JsonProperty(PropertyName = "cattype")]
        public String Cattype { get; set; }
        //[JsonProperty(PropertyName = "price")]
        public int Price { get; set; }
        //[JsonProperty(PropertyName = "city")]
        public String City { get; set; }
        //[JsonProperty(PropertyName = "remark")]
        public String Remark { get; set; }
    }
}