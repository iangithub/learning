﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Azure.Search;

namespace AzureSearch.Models
{
    public static class Helper
    {
        public static SearchIndexClient CreateSearchIndexClient()
        {
            string searchServiceName = "search0129";
            string queryApiKey = "717FBCB4739DE4CD2EA56D144BC9CEF9";

            SearchIndexClient serviceClient = new SearchIndexClient(searchServiceName, "azuresql-index", new SearchCredentials(queryApiKey));
            return serviceClient;
        }
    }
}