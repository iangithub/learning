﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ComputerVisionUseAPI
{
    //Describe Image & Detect Objects
    class Program
    {
        private const string subscriptionKey = "d0967226ef404ffaa15d4ee1c0c5dcc4";
        //private const string endpoint = "https://japanwest.api.cognitive.microsoft.com/vision/v2.0/describe";
        private const string endpoint = "https://japanwest.api.cognitive.microsoft.com/vision/v2.0/detect";

        private const string imgfile = "img/3.jpg";

        static void Main(string[] args)
        {
            if (File.Exists(imgfile))
            {
                try
                {
                    MakeAnalysisRequest(imgfile);
                    Console.WriteLine("辨識中 ....\n");
                }
                catch (Exception e)
                {
                    Console.WriteLine("\n" + e.Message + "\nPress Enter to exit...\n");
                }
            }
            else
            {
                Console.WriteLine("\n 檔案不存在 \n");
            }
            Console.ReadLine();
        }

        static async void MakeAnalysisRequest(string imageFilePath)
        {
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subscriptionKey);

            // Request parameters.
            string requestParameters = "language=en";

            // Assemble the URI for the REST API Call.
            string uri = endpoint + "?" + requestParameters;

            HttpResponseMessage response;

            // Request body. Posts a locally stored JPEG image.
            byte[] byteData = GetImageAsByteArray(imageFilePath);

            using (ByteArrayContent content = new ByteArrayContent(byteData))
            {
                content.Headers.ContentType =
                    new MediaTypeHeaderValue("application/octet-stream");

                // Execute the REST API call.
                response = await client.PostAsync(uri, content);

                // Get the JSON response.
                string contentString = await response.Content.ReadAsStringAsync();

                // Display the JSON response.
                Console.WriteLine("\n 辨識結果:\n");
                Console.WriteLine(contentString);
            }
        }

        static byte[] GetImageAsByteArray(string imageFilePath)
        {
            using (FileStream fileStream =
                new FileStream(imageFilePath, FileMode.Open, FileAccess.Read))
            {
                BinaryReader binaryReader = new BinaryReader(fileStream);
                return binaryReader.ReadBytes((int)fileStream.Length);
            }
        }
    }
}
