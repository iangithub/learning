﻿using Newtonsoft.Json;
using System;

/// <summary>
/// 開始對話Json格式
/// </summary>
public class DLConversation
{
    [JsonProperty("conversationId")]
    public string ConversationId { get; set; }
    [JsonProperty("token")]
    public string Token { get; set; }
    [JsonProperty("expires_in")]
    public int ExpiresIn { get; set; }
    [JsonProperty("streamUrl")]
    public string StreamUrl { get; set; }
    [JsonProperty("referenceGrammarId")]
    public string ReferenceGrammarId { get; set; }
}

/// <summary>
/// 
/// </summary>
public class DLSendMsg
{
    [JsonProperty("type")]
    public string Type { get; set; }
    [JsonProperty("from")]
    public MsgFrom From { get; set; }
    [JsonProperty("text")]
    public string Text { get; set; }
}

public class MsgFrom
{
    [JsonProperty("id")]
    public string Id { get; set; }
}


public class BotReplyObject
{
    public Activity[] activities { get; set; }
    public string watermark { get; set; }
}

public class Activity
{
    public string type { get; set; }
    public string id { get; set; }
    public DateTime timestamp { get; set; }
    public string channelId { get; set; }
    public From from { get; set; }
    public Conversation conversation { get; set; }
    public string text { get; set; }
    public object[] attachments { get; set; }
    public object[] entities { get; set; }
    public string replyToId { get; set; }
    public string serviceUrl { get; set; }
    public DateTime localTimestamp { get; set; }
}

public class From
{
    public string id { get; set; }
    public string name { get; set; }
}

public class Conversation
{
    public string id { get; set; }
}
