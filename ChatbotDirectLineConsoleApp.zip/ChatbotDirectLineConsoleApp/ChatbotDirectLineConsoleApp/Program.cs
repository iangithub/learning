﻿using Microsoft.Bot.Connector.DirectLine;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace ChatbotDirectLineConsoleApp
{
    class Program
    {
        readonly static string _authkey = "fJuAY51ksh8.PGimGDgzptzXXA4fL3w8nyx2HRIffgBwSTXpWdZysKU";
        readonly static string _botid = "mybot0301";
        readonly static string directlineurl = "https://directline.botframework.com";

        static void Main(string[] args)
        {
            StartConversation().Wait();
        }

        //開始對話(Direct Line 對話是由用戶端主動觸發)
        private static async Task StartConversation()
        {
            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage())
                {
                    request.Method = HttpMethod.Post;
                    request.RequestUri = new Uri(directlineurl + "/v3/directline/conversations");
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _authkey);
                    var response = await client.SendAsync(request);
                    var responsebody = await response.Content.ReadAsStringAsync();
                    var conversation = JsonConvert.DeserializeObject<DLConversation>(responsebody);

                    new System.Threading.Thread(async () => await BotReplyMessage(conversation.ConversationId, conversation.Token)).Start();


                    Console.WriteLine("Bot :  ");
                    var userid = Guid.NewGuid();

                    //Wait User Input
                    while (true)
                    {
                        string userinput = Console.ReadLine().Trim();

                        if (userinput.Length > 0)
                        {
                            await UserSendmessage(userid.ToString(), userinput, conversation.ConversationId, conversation.Token);
                        }
                    }
                }
            }
        }

        private static async Task<string> UserSendmessage(string userid, string userinput, string conversationid, string conversationtoken)
        {
            string result = string.Empty;
            try
            {
                using (var client = new HttpClient())
                {
                    using (var request = new HttpRequestMessage())
                    {
                        var sendmsg = new DLSendMsg();
                        sendmsg.Type = "message";
                        sendmsg.From = new MsgFrom() { Id = userid };
                        sendmsg.Text = userinput;

                        request.Method = HttpMethod.Post;
                        request.RequestUri = new Uri(directlineurl + "/v3/directline/conversations/" + conversationid + "/activities");
                        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", conversationtoken);
                        request.Content = new StringContent(JsonConvert.SerializeObject(sendmsg)
                            , Encoding.UTF8, "application/json");

                        var response = await client.SendAsync(request);
                        result = await response.Content.ReadAsStringAsync();
                    }
                }
            }
            catch (Exception ex)
            {
                result = ex.ToString();
            }

            return result;
        }

        private static async Task<string> BotReplyMessage(string conversationid, string conversationtoken)
        {
            string result = string.Empty;
            string watermark = null;

            try
            {
                while (true)
                {
                    using (var client = new HttpClient())
                    {
                        using (var request = new HttpRequestMessage())
                        {

                            request.Method = HttpMethod.Get;
                            request.RequestUri = new Uri(directlineurl + "/v3/directline/conversations/" + conversationid + "/activities?watermark=" + watermark);
                            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", conversationtoken);

                            var response = await client.SendAsync(request);
                            var responsebody = await response.Content.ReadAsStringAsync();
                            var replyobj = JsonConvert.DeserializeObject<BotReplyObject>(responsebody);

                            watermark = replyobj.watermark;

                            var activities = replyobj.activities.Where(x => x.@from.id == _botid);

                            foreach (Activity item in activities)
                            {
                                Console.WriteLine(item.text);
                                Console.WriteLine("USER : ");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = ex.ToString();
            }

            return result;
        }
    }
}
